import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';
import 'package:pinaka_pos/Database/db_helper.dart';
import 'package:pinaka_pos/Models/Assets/asset_model.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../../Blocs/Orders/order_bloc.dart';
import '../../Database/assets_db_helper.dart';
import '../../Database/order_panel_db_helper.dart';
import '../../Database/user_db_helper.dart';
import '../../Helper/Extentions/nav_layout_manager.dart';
import '../../Helper/Extentions/theme_notifier.dart';
import '../../Preferences/pinaka_preferences.dart';
import '../../Widgets/widget_order_screen_panel.dart';
import '../../Widgets/widget_order_status.dart';
import '../../Widgets/widget_filter_chip.dart';
import '../../Widgets/widget_range_filter.dart';
import '../../Widgets/widget_topbar.dart';
import '../../Models/Orders/get_orders_model.dart' as model; // Added prefix
import '../../Repositories/Orders/order_repository.dart';
import '../../Helper/api_response.dart';
import '../../Constants/text.dart';
import '../../Widgets/widget_navigation_bar.dart' as custom_widgets;


/// Last successful Total Orders list for the same filters/page (instant paint on return).
class _TotalOrdersListCache {
  static String? _key;
  static List<model.OrderModel> _pageOrders = [];
  static int _totalCount = 0;

  static void update(
      String key,
      List<model.OrderModel> pageOrders,
      int totalCount,
      ) {
    _key = key;
    _pageOrders = List<model.OrderModel>.from(pageOrders);
    _totalCount = totalCount;
  }

  static bool restoreIfMatch(
      String key,
      void Function(List<model.OrderModel> orders, int totalCount) apply,
      ) {
    if (_key != key) return false;
    apply(List<model.OrderModel>.from(_pageOrders), _totalCount);
    return true;
  }
}

class TotalOrdersScreen extends StatefulWidget {
  // Build #1.0.226: updated class name
  final int? lastSelectedIndex;

  const TotalOrdersScreen({super.key, this.lastSelectedIndex});

  @override
  State<TotalOrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<TotalOrdersScreen>
    with LayoutSelectionMixin {
  late OrderBloc _orderBloc;
  List<model.OrderModel> _orders = []; // Use model.OrderModel
  int _selectedSidebarIndex = 3;
  DateTime now = DateTime.now();
  List<int> quantities = [1, 1, 1, 1];
  bool isLoading = false; // Build #1.0.104
  String _selectedStatusFilter = "All";
  String _selectedUserFilter = "All";
  String _selectedOrderTypeFilter = "All";
  String _selectedPaymentMethodFilter = "All";
  late double _minSalesAmount;
  late double _maxSalesAmount;
  late RangeValues _salesAmountRange;
  String? _sortColumn;
  bool _isAscending = true;
  StreamSubscription? _fetchOrdersSubscription;
  int _totalOrdersCount = 0;
  bool _fetchInProgress = false;
  Timer? _loadingDelayTimer;
  final TextEditingController _searchController = TextEditingController();
  Timer? _searchDebounce;

  ///Filters
  // List<String> _availableStatuses = ["All"];
  final List<OrderStatus> _filterStatuses = [
    OrderStatus(slug: "", name: "All")
  ];
  final List<Employees> _filterUsers = [Employees(iD: "", displayName: "All")];
  final List<OrderType> _filterOrderType = [OrderType(slug: "", name: "All")];

  // Page-level lazy loading
  final ScrollController _tableScrollController = ScrollController();

  List<model.OrderModel> _pageOrders = []; // full page data (20)
  List<model.OrderModel> _visibleOrders = []; // shown data (10 → 20)

  int _chunkSize = 10;
  int _currentChunk = 1;

  Map<String, dynamic>? _selectedOrder;
  // int? _selectedOrderId; // Build #1.0.248: right now saving in order helper class , because state level saving resetting after re build
  /// OrderHelper already singleton class , no need to create instance here again
  // final OrderHelper orderHelper = OrderHelper(); // Helper instance to manage orders
  // final PinakaPreferences _preferences = PinakaPreferences(); //Build #1.0.234: No need
  // Date range filter variables
  DateTime? _startDate;
  DateTime? _endDate;
  bool _isDateRangeApplied = false;
  String? panelDate;
  String?
  panelTime; // Build #1.0.226: UPDATED to widget level to class level declaration // ADD this logic to determine the date and time for the panel

  // Add these variables for pagination
  int _currentPage = 1;
  int _rowsPerPage = 10;
  final List<int> _rowsPerPageOptions = [10, 20, 50, 100];

  // FIX #1: Track the last fetch sequence to cancel stale completions
  int _fetchSequence = 0;

  dynamic _extractMeta(Map map, String key) {
    if (map["request"]?["meta_data"] is List) {
      for (var m in map["request"]["meta_data"]) {
        if (m["key"] == key) return m["value"];
      }
    }
    return null;
  }

  /// Avoids [Iterable.firstWhere] when no match (e.g. filter lists still loading).
  OrderStatus _resolveStatusFilterEntry() {
    for (final e in _filterStatuses) {
      if (e.name == _selectedStatusFilter) return e;
    }
    if (_filterStatuses.isNotEmpty) return _filterStatuses.first;
    return OrderStatus(slug: "", name: "All");
  }

  Employees _resolveUserFilterEntry() {
    for (final e in _filterUsers) {
      if (e.displayName == _selectedUserFilter) return e;
    }
    if (_filterUsers.isNotEmpty) return _filterUsers.first;
    return Employees(iD: "", displayName: "All");
  }

  OrderType _resolveOrderTypeFilterEntry() {
    for (final e in _filterOrderType) {
      if (e.name == _selectedOrderTypeFilter) return e;
    }
    if (_filterOrderType.isNotEmpty) return _filterOrderType.first;
    return OrderType(slug: "", name: "All");
  }

  String _orderTypeLabelForOrder(model.OrderModel order) {
    final apiType = order.orderType?.trim() ?? '';
    final via = order.createdVia.toString().trim();
    final type = apiType.isNotEmpty ? apiType : via;
    for (final e in _filterOrderType) {
      if (e.slug == type) return e.name;
    }
    final normalized = type.toLowerCase();
    if (normalized == 'rest-api') return 'Shop Order';
    if (normalized.isEmpty) return '-';
    return type;
  }

  /// Same line items as the Total Orders API row — used to paint the right panel immediately.
  // List<model.LineItem>? _previewLineItemsForSelectedOrder() {
  //   final id = OrderHelper().selectedOrderId;
  //   if (id == null || id < 0) return null;
  //   for (final o in _pageOrders) {
  //     if (o.id == id) return o.lineItems;
  //   }
  //   for (final o in _orders) {
  //     if (o.id == id) return o.lineItems;
  //   }
  //   return null;
  // }

  /// Same line items as the Total Orders API row — used to paint the right panel immediately.
  List<model.LineItem>? _previewLineItemsForSelectedOrder() {
    final id = OrderHelper().selectedOrderId;
    if (id == null || id < 0) return null;

    // Priority: pageOrders (full data) > _orders
    for (final o in _pageOrders) {
      if (o.id == id) return o.lineItems;
    }
    for (final o in _orders) {
      if (o.id == id) return o.lineItems;
    }
    return null;
  }

  /// NEW: Enhanced preview order with better discount/tax handling
  model.OrderModel? _previewOrderForSelectedOrder() {
    final id = OrderHelper().selectedOrderId;
    if (id == null || id < 0) return null;

    for (final o in _pageOrders) {
      if (o.id == id) return o;
    }
    for (final o in _orders) {
      if (o.id == id) return o;
    }
    return null;
  }

  /// Same order object as the list row — hydrates panel status, discounts, and tags before SQLite sync.
  // model.OrderModel? _previewOrderForSelectedOrder() {
  //   final id = OrderHelper().selectedOrderId;
  //   if (id == null || id < 0) return null;
  //   for (final o in _pageOrders) {
  //     if (o.id == id) return o;
  //   }
  //   for (final o in _orders) {
  //     if (o.id == id) return o;
  //   }
  //   return null;
  // }

  @override
  void initState() {
    super.initState();
    _selectedSidebarIndex = widget.lastSelectedIndex ?? 3;
    _orderBloc = OrderBloc(OrderRepository());
    // Preserve POS context so when navigating back to Fast Keys/Categories/Add,
    // the order panel shows the order we were working on, not the order viewed here
    final oh = OrderHelper();
    if (oh.activeOrderId != null) {
      oh.saveLastActiveOrderId(oh.activeOrderId!);
    }
    _searchController.addListener(() {
      setState(() {}); // 🔥 Forces UI refresh for suffixIcon
    });
    _minSalesAmount = 0.0;
    _maxSalesAmount = 10000.0; // Default max, will be updated from API
    _salesAmountRange = RangeValues(_minSalesAmount, _maxSalesAmount);
    initFilters();
    _tableScrollController.addListener(() {
      if (_rowsPerPage <= _chunkSize) return;

      // ✅ NEW GUARD
      if (!_tableScrollController.position.hasContentDimensions) return;
      if (_tableScrollController.position.maxScrollExtent == 0) return;

      if (_tableScrollController.position.pixels >=
          _tableScrollController.position.maxScrollExtent - 80) {
        final maxChunks = (_pageOrders.length / _chunkSize).ceil();

        if (!isLoading && _currentChunk < maxChunks) {
          setState(() {
            _currentChunk++;
            _visibleOrders =
                _pageOrders.take(_currentChunk * _chunkSize).toList();
            _orders = _visibleOrders;
          });
        }
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final cacheKey = _ordersFetchCacheKey();
      // FIX #2: Cache restore always selects the FIRST order, never a stale ID
      _TotalOrdersListCache.restoreIfMatch(cacheKey, (list, total) {
        if (!mounted) return;
        setState(() {
          _pageOrders = list;
          _currentChunk = 1;
          _visibleOrders = _pageOrders.take(_chunkSize).toList();
          _orders = _visibleOrders;
          _totalOrdersCount = total;
          isLoading = false;
        });
        final sourceOrders = _pageOrders.isNotEmpty ? _pageOrders : _orders;
        if (sourceOrders.isEmpty) {
          OrderHelper().selectedOrderId = null;
        } else {
          // FIX #2: Always default to FIRST order on cache restore
          final firstOrderId = sourceOrders.first.id;
          OrderHelper().selectedOrderId = firstOrderId;
          _onOrderRowSelected(firstOrderId);
        }
      });

      _fetchOrders();

      if (OrderHelper().selectedOrderId == null) {
        _onOrderRowSelected(-1);
      }
    });
  }

  bool get _hasMoreLazyData {
    if (_rowsPerPage <= _chunkSize) return false;

    final maxChunks = (_pageOrders.length / _chunkSize).ceil();
    return _currentChunk < maxChunks;
  }

  Future<void> initFilters() async {
    var filterStatuses = await AssetDBHelper.instance.getOrderStatusList();
    filterStatuses.removeWhere((e) => e.slug == TextConstants.processing);
    _filterStatuses.addAll(filterStatuses);

    var filterUsers = await AssetDBHelper.instance.getEmployeeList();
    _filterUsers.addAll(filterUsers);

    var filterOrderType = await AssetDBHelper.instance.getOrderTypeList();
    _filterOrderType.addAll(filterOrderType);
  }

  /// Stable key for [_TotalOrdersListCache] (must match params sent to [OrderBloc.fetchTotalOrdersCount]).
  String _ordersFetchCacheKey() {
    final selectedStatus = _resolveStatusFilterEntry().slug ?? "";
    final selectedUserId = _resolveUserFilterEntry().iD ?? "";
    final selectedOrderType = _resolveOrderTypeFilterEntry().slug ?? "";
    final format = DateFormat('yyyy-MM-dd');
    final searchQuery = _searchController.text.trim(); // ✅ NO encoding
    String startDateFormatted = "";
    String endDateFormatted = "";
    if (_startDate != null && _endDate != null) {
      startDateFormatted = format.format(_startDate!);
      endDateFormatted = format.format(_endDate!);
    }
    return '${_currentPage}_${_rowsPerPage}_${selectedStatus}_${selectedUserId}_${selectedOrderType}_${startDateFormatted}_${endDateFormatted}_${searchQuery}';
  }

  void _fetchOrders() {
    debugPrint("OrdersScreen: Initiating fetch orders");
    debugPrint("🚀 Fetch Orders Called");

    // FIX #3: Increment sequence so any stale stream callbacks can be ignored
    final int mySequence = ++_fetchSequence;

    final String fetchCacheKey = _ordersFetchCacheKey();
    final searchQuery = _searchController.text.trim(); // ✅ NO encoding
    debugPrint("🔎 Search Query (RAW): $searchQuery");
    debugPrint("📄 Current Page: $_currentPage");

    debugPrint("🔥 FETCH CALLED AT: ${DateTime.now()}");
    _fetchOrdersSubscription?.cancel();
    _loadingDelayTimer?.cancel();
    _loadingDelayTimer = null;
    _fetchInProgress = false;

    _fetchOrdersSubscription =
        _orderBloc.fetchTotalOrdersStream.listen((response) {
          if (!mounted) return;
          // FIX #3: Ignore stale responses from previous fetch calls
          if (mySequence != _fetchSequence) return;

          if (response.status == Status.COMPLETED) {
            _fetchInProgress = false;
            _loadingDelayTimer?.cancel();
            _loadingDelayTimer = null;

            final orders = response.data?.ordersData ?? [];

            _TotalOrdersListCache.update(
              fetchCacheKey,
              orders,
              response.data?.orderTotalCount ?? 0,
            );

            setState(() {
              _pageOrders = orders;
              _currentChunk = 1;

              _visibleOrders = _pageOrders.take(_chunkSize).toList();
              _orders = _visibleOrders;

              _totalOrdersCount = response.data?.orderTotalCount ?? 0;
              isLoading = false;
            });

            // FIX #4: Always select FIRST order after every fetch
            // This fixes: new order arrives → 2nd order was selected instead of 1st
            final sourceOrders = _pageOrders.isNotEmpty ? _pageOrders : _orders;
            if (sourceOrders.isEmpty) {
              OrderHelper().selectedOrderId = null;
              return;
            }

            // Always select the first order in the list
            final int firstOrderId = sourceOrders.first.id;
            OrderHelper().selectedOrderId = firstOrderId;
            _onOrderRowSelected(firstOrderId);
          }

          // ERROR
          else if (response.status == Status.ERROR) {
            _fetchInProgress = false;
            _loadingDelayTimer?.cancel();
            _loadingDelayTimer = null;

            setState(() => isLoading = false);

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Failed to fetch orders"),
                backgroundColor: Colors.red,
              ),
            );
          }

          // LOADING
          else if (response.status == Status.LOADING) {
            _fetchInProgress = true;
            _loadingDelayTimer?.cancel();

            // Avoid full-screen loader when we already have rows (silent refresh).
            if (_pageOrders.isEmpty) {
              _loadingDelayTimer = Timer(
                const Duration(milliseconds: 300),
                    () {
                  if (mounted && _fetchInProgress) {
                    setState(() => isLoading = true);
                  }
                },
              );
            }
          }
        });

    // 🔥 Call Bloc (NOT repository directly)
    final selectedStatus = _resolveStatusFilterEntry().slug ?? "";

    final selectedUserId = _resolveUserFilterEntry().iD ?? "";

    final selectedOrderType = _resolveOrderTypeFilterEntry().slug ?? "";

    DateFormat format = DateFormat('yyyy-MM-dd');
    String startDateFormatted = "";
    String endDateFormatted = "";

    if (_startDate != null && _endDate != null) {
      startDateFormatted = format.format(_startDate!);
      endDateFormatted = format.format(_endDate!);
    }

    _orderBloc.fetchTotalOrdersCount(
      allStatuses: true,
      pageNumber: _currentPage,
      pageLimit: _rowsPerPage,
      status: selectedStatus,
      orderType: selectedOrderType,
      userId: selectedUserId,
      startDate: startDateFormatted,
      endDate: endDateFormatted,
      search: searchQuery,
    );
  }

  // Sort orders based on column
  void _sortData(String column) {
    setState(() {
      if (_sortColumn == column) {
        _isAscending = !_isAscending;
      } else {
        _sortColumn = column;
        _isAscending = true;
      }

      if (_sortColumn != null) {
        _orders.sort((a, b) {
          switch (column) {
            case 'id':
              return _isAscending ? a.id.compareTo(b.id) : b.id.compareTo(a.id);
            case 'date':
              return _isAscending
                  ? a.dateCreated.compareTo(b.dateCreated)
                  : b.dateCreated.compareTo(a.dateCreated);
            case 'time':
              return _isAscending
                  ? a.dateCreated.compareTo(b.dateCreated)
                  : b.dateCreated.compareTo(a.dateCreated);
            case 'sales_amount':
              final aValue = double.tryParse(a.total) ?? 0.0;
              final bValue = double.tryParse(b.total) ?? 0.0;
              return _isAscending
                  ? aValue.compareTo(bValue)
                  : bValue.compareTo(aValue);
            case 'status':
              return _isAscending
                  ? a.status.compareTo(b.status)
                  : b.status.compareTo(a.status);
            default:
              return 0;
          }
        });
      }
    });
    debugPrint(
        "OrdersScreen: Sorted data by $column, ascending: $_isAscending");
  }

  // Extract sales amount from string
  double _extractSalesAmount(String sales) {
    return double.tryParse(sales.replaceAll(RegExp(r'[^\d.]'), '')) ?? 0.0;
  }

  // Open range filter dialog
  void _openRangeFilterDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: const Text("Select Sales Amount Range"),
          content: SingleChildScrollView(
            child: RangeFilter(
              label: "Sales Amount",
              minValue: _minSalesAmount,
              maxValue: _maxSalesAmount,
              initialRange: _salesAmountRange,
              onRangeChanged: (range) {
                setState(() {
                  _salesAmountRange = range;
                  debugPrint(
                      "OrdersScreen: Sales amount range updated to ${_salesAmountRange.start} - ${_salesAmountRange.end}");
                });
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close"),
            ),
          ],
        );
      },
    );
  }

  // Open date range picker dialog
  void _openDateRangePickerDialog() {
    final themeHelper = Provider.of<ThemeNotifier>(context, listen: false);
    showDialog(
      context: context,
      barrierDismissible: false,

      builder: (context) {
        return AlertDialog(
          backgroundColor: themeHelper.themeMode == ThemeMode.dark
              ? ThemeNotifier.secondaryBackground
              : null,
          title: const Text("Select Date Range"),
          content: SizedBox(
            height: 400,
            width: 350,
            child: SfDateRangePicker(
              onSelectionChanged: _onDateRangeSelectionChanged,
              selectionMode: DateRangePickerSelectionMode.range,
              initialSelectedRange: _startDate != null && _endDate != null
                  ? PickerDateRange(_startDate, _endDate)
                  : null,
              showActionButtons: true,
              onSubmit: (Object? value) {
                Navigator.pop(context);
              },
              onCancel: () {
                Navigator.pop(context);
              },
            ),
          ),
        );
      },
    );
  }

  // Handle date range selection
  void _onDateRangeSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    if (args.value is PickerDateRange) {
      final PickerDateRange range = args.value;
      final currentTime = DateTime.now(); // Get current time
      setState(() {
        //Build #1.0.134: integrated date filter
        _startDate = range.startDate != null
            ? DateTime(
            range.startDate!.year,
            range.startDate!.month,
            range.startDate!.day,
            currentTime.hour,
            currentTime.minute,
            currentTime.second)
            : null;
        _endDate = range.endDate != null
            ? DateTime(
            range.endDate!.year,
            range.endDate!.month,
            range.endDate!.day,
            currentTime.hour,
            currentTime.minute,
            currentTime.second)
            : range.startDate != null
            ? DateTime(
            range.startDate!.year,
            range.startDate!.month,
            range.startDate!.day,
            currentTime.hour,
            currentTime.minute,
            currentTime.second)
            : null;
        _isDateRangeApplied = _startDate != null && _endDate != null;
        _currentPage = 1;

        debugPrint("#### _isDateRangeApplied: $_isDateRangeApplied");
        debugPrint("Start Date: $_startDate");
        debugPrint("End Date: $_endDate");
        // Fetch new data with updated date range
        _fetchOrders();
        debugPrint(
            "OrdersScreen: Date range selected from $_startDate to $_endDate");
      });
    }
  }

  // Clear all filters
  void _clearFilters() {
    setState(() {
      _selectedStatusFilter = "All";
      _selectedUserFilter =
      "All"; // Changed from "User 1" to match initialization
      _selectedPaymentMethodFilter = "All";
      _selectedOrderTypeFilter = "All";
      _salesAmountRange = RangeValues(_minSalesAmount, _maxSalesAmount);
      _startDate = null;
      _endDate = null;
      _isDateRangeApplied = false;
      _currentPage = 1;
      _fetchOrders(); // Fetch new data with cleared filters
      debugPrint("OrdersScreen: Filters cleared");
    });
  }

  // Check if order date falls within selected range
  bool _isDateInRange(String dateCreated) {
    if (!_isDateRangeApplied || _startDate == null || _endDate == null) {
      return true;
    }

    final orderDate = DateTime.tryParse(dateCreated);
    if (orderDate == null) return true;

    final orderDateOnly =
    DateTime(orderDate.year, orderDate.month, orderDate.day);
    final startDateOnly =
    DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
    final endDateOnly =
    DateTime(_endDate!.year, _endDate!.month, _endDate!.day);

    return orderDateOnly
        .isAfter(startDateOnly.subtract(const Duration(days: 1))) &&
        orderDateOnly.isBefore(endDateOnly.add(const Duration(days: 1)));
  }

  @override
  void dispose() {
    _fetchOrdersSubscription?.cancel();
    _loadingDelayTimer?.cancel();
    OrderHelper().selectedOrderId =
    null; // Build #1.0.248: remove selected order when leave the screen !
    _orderBloc.dispose();
    _searchController.dispose();
    debugPrint("OrdersScreen: Disposed");
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    debugPrint("????? OrdersScreen: didChangeDependencies");
  }

  // Build #1.0.143: Fixed Issue : After return from order summary screen , total order screen not refreshing with updated response
  void _refreshOrderList() {
    if (kDebugMode) print("_refreshOrderList called");

    if (!isLoading) {
      setState(() => isLoading = true);
    }

    OrderHelper.notifyOrderPanelToRefresh();
    _fetchOrders();   // This already handles loading via stream
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final themeHelper = Provider.of<ThemeNotifier>(context);
    // Update filteredData where clause
    List<model.OrderModel> filteredData = _orders;

    // Pagination Logic
    final int totalItems = _totalOrdersCount; // Use API-provided total count
    final int totalPages = (totalItems / _rowsPerPage).ceil();
    final List<model.OrderModel> paginatedData =
        _orders; // Use _orders directly

    // Update isFilterApplied check
    bool isFilterApplied = _selectedStatusFilter != "All" ||
        _selectedUserFilter != "All" ||
        _selectedOrderTypeFilter != "All";
    bool isRangeFilterApplied = _salesAmountRange.start > _minSalesAmount ||
        _salesAmountRange.end < _maxSalesAmount;
    return Scaffold(
      body: Column(
        children: [
          // Top Bar
          TopBar(
            screen: Screen.ORDERS,
            onModeChanged: () async {
              /// Build #1.0.192: Fixed -> Exception -> setState() callback argument returned a Future. (onModeChanged in all screens)
              String newLayout;
              if (sidebarPosition == SidebarPosition.left) {
                newLayout = SharedPreferenceTextConstants.navRightOrderLeft;
              } else if (sidebarPosition == SidebarPosition.right) {
                newLayout = SharedPreferenceTextConstants.navBottomOrderLeft;
              } else {
                newLayout = orderPanelPosition == OrderPanelPosition.left
                    ? SharedPreferenceTextConstants.navBottomOrderRight
                    : SharedPreferenceTextConstants.navLeftOrderRight;
              }

              // Update the notifier which will trigger _onLayoutChanged
              PinakaPreferences.layoutSelectionNotifier.value = newLayout;
              //Build #1.0.122: update layout mode change selection to DB
              await UserDbHelper().saveUserSettings(
                  {AppDBConst.layoutSelection: newLayout},
                  modeChange: true);
              // update UI
              setState(() {});
            },
          ),
          const Divider(
            color: Colors.grey,
            thickness: 0.4,
            height: 1,
          ),

          // Main Content
          Expanded(
            child: Row(
              children: [
                // Left Sidebar (Conditional)
                if (sidebarPosition == SidebarPosition.left)
                  custom_widgets.NavigationBar(
                    //Build #1.0.4 : Updated class name LeftSidebar to NavigationBar
                    selectedSidebarIndex: _selectedSidebarIndex,
                    onSidebarItemSelected: (index) {
                      setState(() {
                        _selectedSidebarIndex = index;
                        debugPrint(
                            "OrdersScreen: Sidebar index changed to $index");
                      });
                    },
                    isVertical: true, // Vertical layout for left sidebar
                  ),

                // Order Panel on the Left (Conditional: Only when sidebar is right or bottom with left order panel)
                if (sidebarPosition == SidebarPosition.right ||
                    (sidebarPosition == SidebarPosition.bottom &&
                        orderPanelPosition == OrderPanelPosition.left))
                  OrderScreenPanel(
                    fetchOrders: !isLoading, // Sync with parent's loading state
                    key: ValueKey(
                        'order_screen_panel_${OrderHelper().selectedOrderId}_${sidebarPosition}_$orderPanelPosition'), //Build #1.0.234: Fixed Issue -> Processing Orders showing in order screen bottom mode
                    formattedDate:
                    panelDate ?? '', // Build #1.0.226: updated values
                    formattedTime: panelTime ?? '',
                    quantities: quantities,
                    activeOrderId: OrderHelper().selectedOrderId ??
                        OrderHelper().activeOrderId,
                    previewLineItemsFromApi:
                    _previewLineItemsForSelectedOrder(),
                    previewOrderFromApi: _previewOrderForSelectedOrder(),

                    /// <- ADDED NULL CHECK // BUILD 1.0.213: FIXED RE-OPENED ISSUE [SCRUM-356]: Order items not displaying in Bottom Mode
                    refreshOrderList:
                    _refreshOrderList, // Build #1.0.143: Fixed Issue : After return from order summary screen , total order screen not refreshing with updated response
                  ),

                SizedBox(
                  width: sidebarPosition == SidebarPosition.bottom ? 20 : null,
                ),
                // Main Content (Table layout View)
                Expanded(
                  child: Container(
                    margin: sidebarPosition == SidebarPosition.bottom
                        ? const EdgeInsets.fromLTRB(2, 8, 2, 8)
                        : const EdgeInsets.fromLTRB(2, 12, 0, 12),
                    decoration: BoxDecoration(
                      color: themeHelper.themeMode == ThemeMode.dark
                          ? ThemeNotifier.primaryBackground
                          : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(4, 4, 0, 4),
                    child: Column(
                      children: [
                        // Filters
                        Row(
                          children: [
                            Spacer(),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.085,
                              child: Container(
                                width: 180,
                                margin: const EdgeInsets.symmetric(vertical: 10),
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  color: _searchController.text.isNotEmpty
                                      ? Colors.redAccent
                                      : themeHelper.themeMode == ThemeMode.dark
                                      ? const Color(0xFF252837)
                                      : Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: themeHelper.themeMode == ThemeMode.dark
                                        ? ThemeNotifier.borderColor
                                        : Colors.grey.shade400,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.search,
                                      size: 18,
                                      color: _searchController.text.isNotEmpty
                                          ? Colors.white
                                          : themeHelper.themeMode == ThemeMode.dark
                                          ? ThemeNotifier.textDark
                                          : Colors.black,
                                    ),

                                    const SizedBox(width: 6),

                                    Expanded(
                                      child: TextField(
                                        controller: _searchController,
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          FilteringTextInputFormatter.digitsOnly,
                                        ],
                                        textAlignVertical: TextAlignVertical.center,
                                        onChanged: (value) {
                                          print("🔍 User typed: $value");

                                          _searchDebounce?.cancel();

                                          _searchDebounce = Timer(const Duration(milliseconds: 400), () {
                                            if (!mounted) return;

                                            print("⏱ Debounced: ${_searchController.text}");

                                            setState(() {
                                              _currentPage = 1;
                                            });

                                            _fetchOrders();
                                          });
                                        },
                                        style: TextStyle(
                                          color: _searchController.text.isNotEmpty
                                              ? Colors.white
                                              : themeHelper.themeMode == ThemeMode.dark
                                              ? ThemeNotifier.textDark
                                              : Colors.black,
                                          fontSize: 13,
                                        ),
                                        decoration: const InputDecoration(
                                          hintText: "Search Order ID",
                                          border: InputBorder.none,
                                          isDense: true,
                                        ),
                                      ),
                                    ),

                                    // ✅ CLEAR BUTTON
                                    if (_searchController.text.isNotEmpty)
                                      GestureDetector(
                                        onTap: () {
                                          print("❌ Clear button clicked");

                                          _searchDebounce?.cancel();

                                          _searchController.clear();

                                          setState(() {
                                            _currentPage = 1;
                                            _orders.clear();
                                            _pageOrders.clear();
                                            _visibleOrders.clear();
                                          });

                                          _fetchOrders();
                                        },
                                        child: const Padding(
                                          padding: EdgeInsets.all(6),
                                          child: Icon(Icons.close, size: 18, color: Colors.white),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 20,),
                            Wrap(
                              spacing: 8.0,
                              crossAxisAlignment: WrapCrossAlignment.end,
                              alignment: WrapAlignment.end,
                              runAlignment: WrapAlignment.end,
                              children: [
                                // User Filter
                                FilterChipWidget(
                                  label: "User",
                                  options: _filterUsers
                                      .map((filter) => filter.displayName ?? "")
                                      .toList(),
                                  selectedValue: _selectedUserFilter,
                                  onSelected: (value) {
                                    setState(() {
                                      _selectedUserFilter = value;
                                      _currentPage = 1;
                                      _fetchOrders();
                                      debugPrint(
                                          "OrdersScreen: User filter changed to $value");
                                    });
                                  },
                                ),
                                // Order Type Filter
                                FilterChipWidget(
                                  label: "OrderType",
                                  options: _filterOrderType
                                      .map((e) => e.name)
                                      .toList(),
                                  selectedValue: _selectedOrderTypeFilter,
                                  onSelected: (value) {
                                    setState(() {
                                      _selectedOrderTypeFilter = value;
                                      _currentPage = 1;
                                      _fetchOrders();
                                      debugPrint(
                                          "OrdersScreen: Order type filter changed to $value");
                                    });
                                  },
                                ),
                                // Status Filter
                                FilterChipWidget(
                                  label: "Status",
                                  options: _filterStatuses
                                      .map((filter) => filter.name)
                                      .toList(),
                                  selectedValue: _selectedStatusFilter,
                                  onSelected: (value) {
                                    setState(() {
                                      _selectedStatusFilter = value;
                                      _currentPage = 1;
                                      _fetchOrders();
                                      debugPrint(
                                          "OrdersScreen: Status filter changed to $value");
                                    });
                                  },
                                ),
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 10),
                                  child: GestureDetector(
                                    onTap: _openDateRangePickerDialog,
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset(
                                          'assets/svg/filter_calendar.svg',
                                          width: MediaQuery.of(context)
                                              .size
                                              .width *
                                              0.1,
                                          height: MediaQuery.of(context)
                                              .size
                                              .height *
                                              0.06,
                                          colorFilter: ColorFilter.mode(
                                            _isDateRangeApplied
                                                ? Colors.redAccent
                                                : themeHelper.themeMode ==
                                                ThemeMode.dark
                                                ? Colors.grey
                                                : Color(0xFF6F6F70),
                                            BlendMode.srcIn,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                // Clear Filters
                                if (isFilterApplied ||
                                    isRangeFilterApplied ||
                                    _isDateRangeApplied)
                                  Container(
                                    margin: EdgeInsets.symmetric(vertical: 5),
                                    child: IconButton(
                                      icon: Icon(
                                        Icons.clear,
                                        color: isFilterApplied ||
                                            isRangeFilterApplied ||
                                            _isDateRangeApplied
                                            ? Colors.redAccent
                                            : Colors.black,
                                      ),
                                      onPressed: _clearFilters,
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(width: 20),
                          ],
                        ),
                        const SizedBox(height: 2),

                        // Data Table and Pagination controls
                        Expanded(
                          child: isLoading
                              ? const Center(child: CircularProgressIndicator())
                              : Container(
                            decoration: BoxDecoration(
                              color:
                              themeHelper.themeMode == ThemeMode.dark
                                  ? ThemeNotifier.primaryBackground
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 6,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.all(4),

                            // 🔥 Horizontal scroll ONLY
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width,
                              child: Column(
                                children: [
                                  // ================= HEADER =================
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 12),
                                    decoration: BoxDecoration(
                                      color: themeHelper.themeMode ==
                                          ThemeMode.dark
                                          ? const Color(0xFF252837)
                                          : const Color(0xFF6F6F70),
                                      borderRadius:
                                      const BorderRadius.vertical(
                                        top: Radius.circular(12),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        _buildSortableColumn("ID", 'id'),
                                        _buildSortableColumn(
                                            "Order Type", 'orderType'),
                                        _buildSortableColumn(
                                            "Date", 'date'),
                                        _buildSortableColumn(
                                            "Time", 'time'),
                                        _buildSortableColumn(
                                            "Total", 'sales_amount'),
                                        _buildSortableColumn(
                                            "Status", 'status'),
                                      ],
                                    ),
                                  ),

                                  // ================= BODY =================
                                  Expanded(
                                    child: _orders.isEmpty
                                        ? Center(
                                      child: Text(
                                        _searchController.text.isNotEmpty
                                            ? "No orders found"
                                            : "No orders available",
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    )
                                        : ListView.builder(
                                      controller: _tableScrollController,
                                      physics:
                                      const BouncingScrollPhysics(),
                                      itemCount: _orders.length +
                                          (_hasMoreLazyData ? 1 : 0),
                                      itemBuilder: (context, index) {
                                        // 🔥 Lazy loader
                                        if (index >= _orders.length) {
                                          return const Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 12),
                                            child: Center(
                                              child: SizedBox(
                                                height: 24,
                                                width: 24,
                                                child:
                                                CircularProgressIndicator(
                                                  strokeWidth: 2.5,
                                                ),
                                              ),
                                            ),
                                          );
                                        }

                                        final order = _orders[index];
                                        final date = DateTime.tryParse(
                                            order.dateCreated)
                                            ?.toLocal();
                                        final isSelected = OrderHelper()
                                            .selectedOrderId ==
                                            order.id;

                                        final double total =
                                            double.tryParse(order.total
                                                .toString()) ??
                                                0.0;

                                        return GestureDetector(
                                          onTap: () =>
                                              _onOrderRowSelected(
                                                  order.id),
                                          child: Container(
                                            padding: const EdgeInsets
                                                .symmetric(vertical: 6),
                                            decoration: BoxDecoration(
                                              color: isSelected
                                                  ? (themeHelper
                                                  .themeMode ==
                                                  ThemeMode.dark
                                                  ? const Color(
                                                  0xFF383B4C)
                                                  : const Color(
                                                  0xFFDFDFDF))
                                                  : (themeHelper
                                                  .themeMode ==
                                                  ThemeMode.dark
                                                  ? const Color(
                                                  0xFF201F29)
                                                  : const Color(
                                                  0xFFF9F9F9)),
                                              border: Border(
                                                bottom: BorderSide(
                                                  color: themeHelper
                                                      .themeMode ==
                                                      ThemeMode.dark
                                                      ? const Color(
                                                      0xFF474646)
                                                      : const Color(
                                                      0xFFD8D7D7),
                                                ),
                                              ),
                                            ),
                                            child: Row(
                                              children: [
                                                _buildDataCell(
                                                    order.id.toString()),
                                                _buildDataCell(
                                                  _orderTypeLabelForOrder(
                                                      order),
                                                ),
                                                _buildDataCell(
                                                  date != null
                                                      ? DateFormat(
                                                      TextConstants
                                                          .dateFormat)
                                                      .format(date)
                                                      : '',
                                                ),
                                                _buildDataCell(
                                                  date != null
                                                      ? DateFormat(
                                                      'HH:mm:ss')
                                                      .format(date)
                                                      : '',
                                                ),
                                                _buildDataCell(
                                                  '${total < 0 ? '-' : ''}${order.currencySymbol}${total.abs().toStringAsFixed(2)}',
                                                ),
                                                _buildDataCell(
                                                  order.status,
                                                  isStatus: true,
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        // ADDED: Pagination Controls
                        if (!isLoading && _totalOrdersCount > _rowsPerPage)
                          _buildPaginationControls(totalItems, totalPages),
                      ],
                    ),
                  ),
                ),

                if (sidebarPosition == SidebarPosition.bottom)
                  SizedBox(
                    width:
                    sidebarPosition == SidebarPosition.bottom ? 20 : null,
                  ),
                // Order Panel on the Right
                if (sidebarPosition != SidebarPosition.right &&
                    !(sidebarPosition == SidebarPosition.bottom &&
                        orderPanelPosition == OrderPanelPosition.left))
                  OrderScreenPanel(
                    fetchOrders: !isLoading, // Sync with parent's loading state
                    key: ValueKey(
                        'order_screen_panel_${OrderHelper().selectedOrderId}_${sidebarPosition}_$orderPanelPosition'), //Build #1.0.234: Fixed Issue -> Processing Orders showing in order screen bottom mode
                    formattedDate:
                    panelDate ?? '', // Build #1.0.226: updated values
                    formattedTime: panelTime ?? '',
                    quantities: quantities,
                    activeOrderId: OrderHelper().selectedOrderId ??
                        OrderHelper().activeOrderId,
                    previewLineItemsFromApi:
                    _previewLineItemsForSelectedOrder(),
                    previewOrderFromApi: _previewOrderForSelectedOrder(),

                    /// <- ADDED NULL CHECK // BUILD 1.0.213: FIXED RE-OPENED ISSUE [SCRUM-356]: Order items not displaying in Bottom Mode
                    refreshOrderList:
                    _refreshOrderList, // Build #1.0.143: Fixed Issue : After return from order summary screen , total order screen not refreshing with updated response
                  ),

                // Right Sidebar
                if (sidebarPosition == SidebarPosition.right)
                  custom_widgets.NavigationBar(
                    selectedSidebarIndex: _selectedSidebarIndex,
                    onSidebarItemSelected: (index) {
                      setState(() {
                        _selectedSidebarIndex = index;
                        debugPrint(
                            "OrdersScreen: Sidebar index changed to $index");
                      });
                    },
                    isVertical: true,
                  ),
              ],
            ),
          ),

          // Bottom Sidebar
          if (sidebarPosition == SidebarPosition.bottom)
            custom_widgets.NavigationBar(
              selectedSidebarIndex: _selectedSidebarIndex,
              onSidebarItemSelected: (index) {
                setState(() {
                  _selectedSidebarIndex = index;
                  debugPrint("OrdersScreen: Sidebar index changed to $index");
                });
              },
              isVertical: false,
            ),
        ],
      ),
    );
  }

  // FIX #6: Show loading when new order comes + improved refresh
  void _onOrderRowSelected(int orderId) async {
    debugPrint("OrdersScreen: _onOrderRowSelected id $orderId");

    // Build #1.0.248: Preserve the selection
    OrderHelper().selectedOrderId = orderId;

    // NEW: If this is called from refresh after new order, show loading
    bool shouldShowLoading = orderId == -1 ||
        (OrderHelper().selectedOrderId != null && _pageOrders.isEmpty);

    if (shouldShowLoading && !isLoading) {
      setState(() => isLoading = true);
    }

    // Explicitly declare selectedOrder as a nullable OrderModel
    model.OrderModel? selectedOrder;

    if (orderId == -1 && _orders.isNotEmpty) {
      orderId = _orders.first.id;
      OrderHelper().selectedOrderId = orderId;
    }

    if (OrderHelper().selectedOrderId != null) {
      final selectedId = OrderHelper().selectedOrderId!;
      // FIX #5: Search _pageOrders first (full dataset), then _orders (visible chunk)
      for (final order in _pageOrders) {
        if (order.id == selectedId) {
          selectedOrder = order;
          break;
        }
      }
      if (selectedOrder == null) {
        for (final order in _orders) {
          if (order.id == selectedId) {
            selectedOrder = order;
            break;
          }
        }
      }
    }

    if (selectedOrder != null) {
      final date = DateTime.tryParse(selectedOrder.dateCreated)?.toLocal();
      if (date != null) {
        panelDate = DateFormat(TextConstants.dateFormat).format(date);
        panelTime = DateFormat('hh:mm a').format(date);
      } else {
        panelDate = 'Invalid Date';
        panelTime = 'Invalid Time';
      }
    } else {
      final now = DateTime.now();
      panelDate = DateFormat(TextConstants.dateFormat).format(now);
      panelTime = DateFormat('hh:mm a').format(now);
    }

    // Build #1.0.248: Force UI to update with the new selection
    setState(() {});

    debugPrint("OrdersScreen: Selected order ID ${OrderHelper().selectedOrderId}");
  }

  Widget _buildPaginationControls(int totalItems, int totalPages) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const Text("Rows per page:"),
          const SizedBox(width: 8),

          // ---------------- ROWS PER PAGE ----------------
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(color: Colors.grey.shade400),
            ),
            child: DropdownButton<int>(
              value: _rowsPerPage,
              underline: const SizedBox.shrink(),
              items: _rowsPerPageOptions.map((int value) {
                return DropdownMenuItem<int>(
                  value: value,
                  child: Text(value.toString()),
                );
              }).toList(),
              onChanged: (int? newValue) {
                if (newValue != null) {
                  setState(() {
                    _rowsPerPage = newValue;
                    _currentPage = 1;

                    // 🔥 RESET LAZY STATE
                    _currentChunk = 1;
                    _pageOrders.clear();
                    _visibleOrders.clear();

                    _fetchOrders();
                  });
                }
              },
            ),
          ),

          const SizedBox(width: 24),

          // ---------------- PAGE INFO ----------------
          Text(
            totalItems == 0
                ? '0-0 of 0'
                : '${(_currentPage - 1) * _rowsPerPage + 1}'
                '-${(_currentPage * _rowsPerPage) > totalItems ? totalItems : (_currentPage * _rowsPerPage)}'
                ' of $totalItems',
          ),

          const SizedBox(width: 24),

          // ---------------- FIRST PAGE ----------------
          IconButton(
            icon: const Icon(Icons.first_page),
            onPressed: _currentPage == 1 || totalItems == 0
                ? null
                : () {
              setState(() {
                _currentPage = 1;

                // 🔥 RESET LAZY STATE
                _currentChunk = 1;
                _pageOrders.clear();
                _visibleOrders.clear();

                _fetchOrders();
              });
            },
          ),

          // ---------------- PREVIOUS PAGE ----------------
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: _currentPage == 1 || totalItems == 0
                ? null
                : () {
              setState(() {
                _currentPage--;

                // 🔥 RESET LAZY STATE
                _currentChunk = 1;
                _pageOrders.clear();
                _visibleOrders.clear();

                _fetchOrders();
              });
            },
          ),

          // ---------------- NEXT PAGE ----------------
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: _currentPage == totalPages || totalItems == 0
                ? null
                : () {
              setState(() {
                _currentPage++;

                // 🔥 RESET LAZY STATE
                _currentChunk = 1;
                _pageOrders.clear();
                _visibleOrders.clear();

                _fetchOrders();
              });
            },
          ),

          // ---------------- LAST PAGE ----------------
          IconButton(
            icon: const Icon(Icons.last_page),
            onPressed: _currentPage == totalPages || totalItems == 0
                ? null
                : () {
              setState(() {
                _currentPage = totalPages;

                // 🔥 RESET LAZY STATE
                _currentChunk = 1;
                _pageOrders.clear();
                _visibleOrders.clear();

                _fetchOrders();
              });
            },
          ),
        ],
      ),
    );
  }

  // Build sortable column header
  Widget _buildSortableColumn(String label, String columnKey) {
    final themeHelper = Provider.of<ThemeNotifier>(context);
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.100,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 4.0),
        child: InkWell(
          onTap: () {
            _sortData(columnKey);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    color: themeHelper.themeMode == ThemeMode.dark
                        ? ThemeNotifier.textDark
                        : Color(0xFFFFFFFF),
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 4),
              if (_sortColumn == columnKey)
                Icon(
                  _isAscending ? Icons.arrow_upward : Icons.arrow_downward,
                  color: Colors.blue,
                  size: 16,
                )
              else
                Icon(
                  Icons.unfold_more,
                  color: themeHelper.themeMode == ThemeMode.dark
                      ? ThemeNotifier.textDark
                      : Colors.white,
                  size: 16,
                ),
            ],
          ),
        ),
      ),
    );
  }

  // Build header cell
  Widget _buildHeaderCell(String text) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.105,
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.grey,
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  // Build data cell
  Widget _buildDataCell(String text, {bool isStatus = false}) {
    final themeHelper = Provider.of<ThemeNotifier>(context);
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.100,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 4.0),
        child: isStatus
            ? StatusWidget(
          status: text,
          dotSize: 8.0,
          fontSize: 14.0,
        )
            : Text(
          text,
          style: TextStyle(
            color: themeHelper.themeMode == ThemeMode.dark
                ? ThemeNotifier.textDark
                : Colors.black87,
            fontSize: 14,
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }
}