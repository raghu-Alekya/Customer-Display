// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';
// import 'package:syncfusion_flutter_datepicker/datepicker.dart';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/foundation.dart';
//
// import '../../Constants/text.dart';
// import '../../Helper/Extentions/theme_notifier.dart';
// import '../../Preferences/pinaka_preferences.dart';
// import '../../Widgets/widget_navigation_bar.dart' as custom_widgets;
// import '../../Widgets/widget_topbar.dart';
// import '../Database/db_helper.dart';
// import '../Database/user_db_helper.dart';
// import '../Helper/Extentions/nav_layout_manager.dart';
// import '../Helper/url_helper.dart';
// import '../Models/Orders/refund_orderlist_model.dart';
// import '../Repositories/Orders/refund_validation_repository.dart';
// import '../Widgets/refund_checkin_popup.dart';
// import '../Blocs/Orders/refund_validation_bloc.dart';
//
// enum SidebarPosition { left, right, bottom }
//
// enum OrderPanelPosition { left, right }
//
// List<String> allData = List.generate(27, (i) => "Item ${i + 1}");
//
// class CompletedOrdersScreen extends StatefulWidget {
//   final int lastSelectedIndex;
//   const CompletedOrdersScreen({super.key, required this.lastSelectedIndex});
//
//   @override
//   State<CompletedOrdersScreen> createState() => _CompletedOrdersScreenState();
// }
//
// class _CompletedOrdersScreenState extends State<CompletedOrdersScreen>
//     with WidgetsBindingObserver, LayoutSelectionMixin {
//
//   int _selectedSidebarIndex = 5;
//   int _currentPage = 1;
//   int itemsPerPage = 10;
//   final List<int> _rowsPerPageOptions = [10, 20, 50, 100];
//   int _rowsPerPage = 10;
//   DateTime? selectedDate;
//   List<int> quantities = [];
//   DateTime? _startDate;
//   DateTime? _endDate;
//   bool _isDateRangeApplied = false;
//   static bool isActive = false;
//
//   List<CompletedOrder> _allOrders = [];
//   List<CompletedOrder> filteredOrders = [];
//   List<CompletedOrder> _pagedOrders = [];
//   List<CompletedOrder> _visibleOrders = [];
//
//   // ✅ NEW: Loading and error states
//   bool _isLoading = false;
//   String? _errorMessage;
//
//   int get _totalPages {
//     final pages = _rowsPerPage > 0 ? (filteredOrders.length / _rowsPerPage).ceil() : 1;
//     return pages == 0 ? 1 : pages;
//   }
//
//   TextEditingController searchController = TextEditingController();
//   String selectedStatus = 'Completed';
//   String? selectedTransactionId;
//   List<String> transactionIds = [];
//   Map<int, String?> selectedTxnPerOrder = {};
//   List<String> transactionIdOptions = [];
//   bool _isModeChangePending = false;
//   bool _isNavigatingAway = false;
//
//   List<CompletedOrder> _orders = [];
//
//   String _todayStart() {
//     final now = DateTime.now();
//     final start = DateTime(now.year, now.month, now.day, 0, 0, 0);
//     return start.toIso8601String();
//   }
//
//   String _todayEnd() {
//     final now = DateTime.now();
//     final end = DateTime(now.year, now.month, now.day, 23, 59, 59);
//     return end.toIso8601String();
//   }
//
//   void _paginate() {
//     final int totalPages = _totalPages;
//     if (_currentPage > totalPages) {
//       _currentPage = totalPages;
//     }
//     if (_currentPage < 1) {
//       _currentPage = 1;
//     }
//
//     final startIndex = (_currentPage - 1) * _rowsPerPage;
//     final endIndex = startIndex + _rowsPerPage;
//
//     if (startIndex >= filteredOrders.length) {
//       _pagedOrders = [];
//     } else {
//       _pagedOrders = filteredOrders.sublist(
//         startIndex,
//         endIndex > filteredOrders.length ? filteredOrders.length : endIndex,
//       );
//     }
//   }
//
//   void _loadPage(int page) {
//     setState(() {
//       _currentPage = page;
//       _paginate();
//     });
//   }
//
//   @override
//   void deactivate() {
//     _isNavigatingAway = true;
//     super.deactivate();
//   }
//
//   void _updatePagination() {
//     final startIndex = (_currentPage - 1) * itemsPerPage;
//     final endIndex = startIndex + itemsPerPage;
//
//     setState(() {
//       _pagedOrders = filteredOrders.sublist(
//         startIndex,
//         endIndex > filteredOrders.length ? filteredOrders.length : endIndex,
//       );
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     _selectedSidebarIndex = widget.lastSelectedIndex;
//     _loadCompletedOrders();
//   }
//
//   @override
//   void dispose() {
//     _isNavigatingAway = true;
//     searchController.dispose();
//     super.dispose();
//   }
//
//   //  NEW: Direct API call to load completed orders
//   Future<void> _loadCompletedOrders() async {
//     setState(() {
//       _isLoading = true;
//       _errorMessage = null;
//     });
//
//     try {
//       final orders = await _fetchCompletedOrders(
//         page: 1,
//         perPage: 100, // Load all orders at once for client-side filtering
//       );
//
//       setState(() {
//         _allOrders = orders;
//         filteredOrders = List.from(_allOrders);
//
//         transactionIds = _allOrders
//             .map((o) => o.transactionId)
//             .where((id) => id.isNotEmpty)
//             .toSet()
//             .toList();
//
//         _currentPage = 1;
//         _isLoading = false;
//         _paginate();
//       });
//
//       if (kDebugMode) {
//         debugPrint("✅ Loaded ${orders.length} completed orders");
//       }
//     } catch (e) {
//       setState(() {
//         _errorMessage = e.toString();
//         _isLoading = false;
//       });
//       if (kDebugMode) {
//         debugPrint(" Error loading completed orders: $e");
//       }
//     }
//   }
//
//   // ✅ NEW: Direct fetch method (moved from repository)
//   Future<List<CompletedOrder>> _fetchCompletedOrders({
//     required int page,
//     int? perPage,
//     int? authorId,
//     String? from,
//     String? to,
//   }) async {
//     final token = await _getTokenFromDb();
//
//     // ✅ Build query parameters dynamically
//     final queryParams = {
//       'page': page.toString(),
//       if (perPage != null) 'per_page': perPage.toString(),
//       if (authorId != null) 'author': authorId.toString(),
//       if (from != null && from.isNotEmpty) 'after': from,
//       if (to != null && to.isNotEmpty) 'before': to,
//     };
//
//     final uri = Uri.parse(
//       '${UrlHelper.baseUrl}pinaka-pos/v1/orders/completed-orders',
//     ).replace(queryParameters: queryParams);
//
//     final response = await http.get(
//       uri,
//       headers: {
//         'Authorization': 'Bearer $token',
//         'Accept': 'application/json',
//       },
//     );
//
//     if (kDebugMode) {
//       print("completed orders Status Code: ${response.statusCode}");
//       print("Body: ${response.body}");
//     }
//
//     if (response.statusCode != 200) {
//       throw Exception(
//         'Failed to load completed orders (status: ${response.statusCode})',
//       );
//     }
//
//     final decoded = jsonDecode(response.body);
//     if (kDebugMode) {
//       print("DECODED JSON:");
//       debugPrint(decoded.toString());
//     }
//
//     // ✅ Safe parsing
//     if (decoded == null ||
//         decoded['orders_data'] == null ||
//         decoded['orders_data'] is! List) {
//       return [];
//     }
//
//     final List ordersList = decoded['orders_data'];
//
//     return ordersList
//         .map((e) => CompletedOrder.fromJson(e))
//         .toList();
//   }
//
//   // ✅ Helper to get token from DB
//   Future<String> _getTokenFromDb() async {
//     final db = await DBHelper.instance.database;
//
//     final result = await db.query(
//       AppDBConst.userTable,
//       where:
//       '${AppDBConst.userToken} IS NOT NULL AND ${AppDBConst.userToken} != ""',
//       orderBy: '${AppDBConst.userId} DESC',
//       limit: 1,
//     );
//
//     if (result.isEmpty) {
//       throw Exception('No active user token found in database');
//     }
//
//     final token = result.first[AppDBConst.userToken] as String;
//
//     if (kDebugMode) {
//       print('Using JWT token: ${token.substring(0, 20)}...');
//     }
//
//     return token;
//   }
//
//   // ✅ FIX: Helper to compute sidebar position fresh from notifier
//   SidebarPosition _getSidebarPosition(String layout) {
//     if (layout == SharedPreferenceTextConstants.navRightOrderLeft) return SidebarPosition.right;
//     if (layout == SharedPreferenceTextConstants.navBottomOrderLeft) return SidebarPosition.bottom;
//     if (layout == SharedPreferenceTextConstants.navBottomOrderRight) return SidebarPosition.bottom;
//     return SidebarPosition.left;
//   }
//
//   // ✅ FIX: Helper to compute order panel position fresh from notifier
//   OrderPanelPosition _getOrderPanelPosition(String layout) {
//     if (layout == SharedPreferenceTextConstants.navRightOrderLeft) return OrderPanelPosition.left;
//     if (layout == SharedPreferenceTextConstants.navBottomOrderLeft) return OrderPanelPosition.left;
//     if (layout == SharedPreferenceTextConstants.navBottomOrderRight) return OrderPanelPosition.right;
//     return OrderPanelPosition.right;
//   }
//
//   /// ✅ FINAL SAFE MODE CHANGE HANDLER
//   void _handleModeChange() async {
//     if (_isNavigatingAway || _isModeChangePending) {
//       print("🚫 [Refund] Mode change BLOCKED - navigating away");
//       return;
//     }
//
//     _isModeChangePending = true;
//     print("🔄 [Refund] Mode toggle requested");
//
//     final String currentLayout = PinakaPreferences.layoutSelectionNotifier.value;
//     final SidebarPosition currentSidebar = _getSidebarPosition(currentLayout);
//     final OrderPanelPosition currentOrderPanel = _getOrderPanelPosition(currentLayout);
//
//     String newLayout;
//     if (currentSidebar == SidebarPosition.left) {
//       newLayout = SharedPreferenceTextConstants.navRightOrderLeft;
//     } else if (currentSidebar == SidebarPosition.right) {
//       newLayout = SharedPreferenceTextConstants.navBottomOrderLeft;
//     } else {
//       newLayout = currentOrderPanel == OrderPanelPosition.left
//           ? SharedPreferenceTextConstants.navBottomOrderRight
//           : SharedPreferenceTextConstants.navLeftOrderRight;
//     }
//
//     print("🔄 [Refund] Changing mode to: $newLayout");
//
//     PinakaPreferences.layoutSelectionNotifier.value = newLayout;
//
//     await UserDbHelper().saveUserSettings(
//       {AppDBConst.layoutSelection: newLayout},
//       modeChange: true,
//     );
//
//     // Reset after small delay
//     Future.delayed(const Duration(milliseconds: 400), () {
//       if (mounted) _isModeChangePending = false;
//     });
//     if (mounted) {
//       setState(() {});
//     }
//   }
//
//   // ✅ Refresh method
//   Future<void> _refreshOrders() async {
//     await _loadCompletedOrders();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final themeHelper = Provider.of<ThemeNotifier>(context);
//
//     return ValueListenableBuilder<String>(
//       valueListenable: PinakaPreferences.layoutSelectionNotifier,
//       builder: (context, layout, _) {
//         final SidebarPosition sidebarPosition = _getSidebarPosition(layout);
//         final OrderPanelPosition orderPanelPosition = _getOrderPanelPosition(layout);
//
//         return Scaffold(
//           body: Column(
//             children: [
//               /// 🔹 TOP BAR (same as Orders screen)
//               TopBar(
//                 screen: Screen.ORDERS,
//                 onModeChanged: _handleModeChange,
//               ),
//               const Divider(height: 1, thickness: 0.4),
//
//               /// 🔹 MAIN CONTENT
//               Expanded(
//                 child: Row(
//                   children: [
//                     /// 🔹 LEFT SIDEBAR
//                     if (sidebarPosition == SidebarPosition.left)
//                       custom_widgets.NavigationBar(
//                         selectedSidebarIndex: _selectedSidebarIndex,
//                         isVertical: true,
//                         onSidebarItemSelected: (index) {
//                           setState(() => _selectedSidebarIndex = index);
//                         },
//                       ),
//
//                     /// 🔹 CENTER CONTENT (Completed Orders Table)
//                     Expanded(
//                       child: _buildContent(themeHelper),
//                     ),
//
//                     /// 🔹 RIGHT SIDEBAR
//                     if (sidebarPosition == SidebarPosition.right)
//                       custom_widgets.NavigationBar(
//                         selectedSidebarIndex: _selectedSidebarIndex,
//                         isVertical: true,
//                         onSidebarItemSelected: (index) {
//                           setState(() => _selectedSidebarIndex = index);
//                         },
//                       ),
//                   ],
//                 ),
//               ),
//
//               /// 🔹 BOTTOM SIDEBAR
//               if (sidebarPosition == SidebarPosition.bottom)
//                 custom_widgets.NavigationBar(
//                   selectedSidebarIndex: _selectedSidebarIndex,
//                   isVertical: false,
//                   onSidebarItemSelected: (index) {
//                     setState(() => _selectedSidebarIndex = index);
//                   },
//                 ),
//             ],
//           ),
//         );
//       },
//     );
//   }
//
//   // ✅ NEW: Content builder replacing BlocConsumer
//   Widget _buildContent(ThemeNotifier themeHelper) {
//     if (_isLoading) {
//       return const Center(
//         child: CircularProgressIndicator(),
//       );
//     }
//
//     if (_errorMessage != null) {
//       return Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(
//               _errorMessage!,
//               style: const TextStyle(color: Colors.red),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: _refreshOrders,
//               child: const Text('Retry'),
//             ),
//           ],
//         ),
//       );
//     }
//
//     if (filteredOrders.isEmpty) {
//       return const Center(
//         child: Text("No completed orders found"),
//       );
//     }
//
//     return Container(
//       margin: const EdgeInsets.all(12),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         color: themeHelper.themeMode == ThemeMode.dark
//             ? ThemeNotifier.primaryBackground
//             : Colors.white,
//         borderRadius: BorderRadius.circular(12),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.05),
//             blurRadius: 6,
//           ),
//         ],
//       ),
//       child: Column(
//         children: [
//           _buildHeader(),
//           const SizedBox(height: 12),
//           Expanded(
//             child: _buildOrderTable(themeHelper),
//           ),
//           const SizedBox(height: 8),
//           _buildPagination(),
//         ],
//       ),
//     );
//   }
//
//   // ================= HEADER =================
//
//   Widget _buildHeader() {
//     bool isDark = Theme.of(context).brightness == Brightness.dark;
//     return Row(
//       children: [
//         const Text(
//           "Completed Order List",
//           style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//         ),
//         const Spacer(),
//         Container(
//           width: 200,
//           height: 35,
//           decoration: BoxDecoration(
//             color: isDark
//                 ? const Color(0xFF29313F)
//                 : Colors.white,
//             borderRadius: BorderRadius.circular(8),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withOpacity(0.15),
//                 blurRadius: 6,
//                 spreadRadius: 1,
//                 offset: const Offset(0, 3),
//               ),
//             ],
//           ),
//           child: TextField(
//             controller: searchController,
//             textAlignVertical: TextAlignVertical.center,
//             onChanged: (value) {
//               setState(() {
//                 if (value.isEmpty) {
//                   filteredOrders = _allOrders;
//                 } else {
//                   filteredOrders = _allOrders.where((order) {
//                     return order.orderId
//                         .toString()
//                         .toLowerCase()
//                         .contains(value.toLowerCase());
//                   }).toList();
//                 }
//
//                 _currentPage = 1;
//                 _paginate();
//               });
//             },
//             decoration: InputDecoration(
//               hintText: "Search Order ID",
//               hintStyle: TextStyle(
//                 fontFamily: "Inter",
//                 fontSize: 13,
//                 fontWeight: FontWeight.w400,
//                 color: isDark ? Colors.white : const Color(0xFF999393),
//               ),
//               prefixIcon: Icon(
//                 Icons.search,
//                 color: isDark ? Colors.white : const Color(0xFF999393),
//                 size: 18,
//               ),
//               suffixIcon: searchController.text.isNotEmpty
//                   ? IconButton(
//                 icon: Icon(
//                   Icons.close,
//                   color: isDark
//                       ? Colors.white
//                       : const Color(0xFF6B7280),
//                   size: 18,
//                 ),
//                 onPressed: () {
//                   searchController.clear();
//                   setState(() {
//                     filteredOrders = _allOrders;
//                     _currentPage = 1;
//                     _paginate();
//                   });
//                 },
//               )
//                   : null,
//               border: InputBorder.none,
//               enabledBorder: InputBorder.none,
//               focusedBorder: InputBorder.none,
//               contentPadding: const EdgeInsets.symmetric(
//                   vertical: 0),
//               isDense: true,
//             ),
//           ),
//         ),
//         const SizedBox(width: 18),
//         Row(
//           children: [
//             const SizedBox(width: 8),
//
//             // CALENDAR ICON FILTER
//             InkWell(
//               onTap: _openDateRangePickerDialog,
//               child: Container(
//                 padding: const EdgeInsets.all(7),
//                 child: SvgPicture.asset(
//                   'assets/svg/filter_calendar.svg',
//                   width: 32,
//                   height: 32,
//                   colorFilter: ColorFilter.mode(
//                     _isDateRangeApplied
//                         ? Colors.redAccent
//                         : Theme.of(context).colorScheme.onSurface,
//                     BlendMode.srcIn,
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         )
//       ],
//     );
//   }
//
//   void _openDateRangePickerDialog() {
//     final themeHelper = Provider.of<ThemeNotifier>(context, listen: false);
//
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (context) {
//         return AlertDialog(
//           backgroundColor: themeHelper.themeMode == ThemeMode.dark
//               ? ThemeNotifier.secondaryBackground
//               : null,
//           title: const Text("Select Date Range"),
//           content: SizedBox(
//             height: 400,
//             width: 350,
//             child: SfDateRangePicker(
//               selectionMode: DateRangePickerSelectionMode.range,
//               showActionButtons: true,
//               onSelectionChanged: _onDateRangeSelectionChanged,
//               initialSelectedRange: _startDate != null && _endDate != null
//                   ? PickerDateRange(_startDate, _endDate)
//                   : null,
//               onSubmit: (value) => Navigator.pop(context),
//               onCancel: () => Navigator.pop(context),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   void _onDateRangeSelectionChanged(DateRangePickerSelectionChangedArgs args) {
//     if (args.value is PickerDateRange) {
//       final range = args.value as PickerDateRange;
//
//       setState(() {
//         _startDate = range.startDate;
//         _endDate = range.endDate ?? range.startDate;
//
//         _isDateRangeApplied = _startDate != null && _endDate != null;
//
//         _applyDateFilter();
//       });
//     }
//   }
//
//   void _applyDateFilter() {
//     if (!_isDateRangeApplied || _startDate == null || _endDate == null) {
//       filteredOrders = _allOrders;
//     } else {
//       filteredOrders = _allOrders.where((order) {
//         final orderDate = order.completedAt;
//
//         final dateOnly =
//         DateTime(orderDate.year, orderDate.month, orderDate.day);
//
//         final start =
//         DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
//
//         final end = DateTime(_endDate!.year, _endDate!.month, _endDate!.day);
//
//         return dateOnly.isAfter(start.subtract(const Duration(days: 1))) &&
//             dateOnly.isBefore(end.add(const Duration(days: 1)));
//       }).toList();
//     }
//
//     _currentPage = 1;
//     _paginate();
//   }
//
//   // ================= TABLE =================
//
//   Widget _buildOrderTable(ThemeNotifier themeHelper) {
//     bool isDark = Theme.of(context).brightness == Brightness.dark;
//
//     return Container(
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(12),
//         color: themeHelper.themeMode == ThemeMode.dark
//             ? const Color(0xFF201F29)
//             : const Color(0xFFF9F9F9),
//       ),
//       child: Column(
//         children: [
//           /// 🔹 TABLE HEADER
//           Container(
//             padding: const EdgeInsets.only(
//               left: 8,
//               right: 0,
//               top: 14,
//               bottom: 14,
//             ),
//             decoration: BoxDecoration(
//               color: themeHelper.themeMode == ThemeMode.dark
//                   ? const Color(0xFF29313F)
//                   : const Color(0xFF6F6F70),
//               borderRadius:
//               const BorderRadius.vertical(top: Radius.circular(10)),
//             ),
//             child: Row(
//               children: const [
//                 SizedBox(width: 10),
//                 _HeaderCell("Order ID"),
//                 _HeaderCell("Order Type"),
//                 _HeaderCell("Date"),
//                 _HeaderCell("Transaction ID"),
//                 _HeaderCell("Payment Type"),
//                 _HeaderCell("Amount"),
//                 _HeaderCell("Item Tax"),
//                 _HeaderCell("Discount"),
//                 _HeaderCell("Total"),
//                 _HeaderCell("Status"),
//               ],
//             ),
//           ),
//
//           /// 🔹 TABLE BODY
//           Expanded(
//             child: ListView.builder(
//               itemCount: _pagedOrders.length,
//               itemBuilder: (context, index) {
//                 final order = _pagedOrders[index];
//
//                 return InkWell(
//                   onTap: () {
//                     showDialog(
//                       context: context,
//                       barrierDismissible: false,
//                       builder: (dialogContext) {
//                         return BlocProvider(
//                           create: (_) => RefundValidationBloc(
//                             repository: RefundValidationRepository(
//                               baseUrl:
//                               "https://merchantretail.alektasolutions.com",
//                             ),
//                           ),
//                           child: PinCheckInDialog(order: order),
//                         );
//                       },
//                     );
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.only(
//                       left: 10,
//                       right: 10,
//                       top: 10,
//                       bottom: 10,
//                     ),
//                     decoration: BoxDecoration(
//                       color: isDark ? const Color(0xFF212231) : Colors.white,
//                       border: Border(
//                         bottom: BorderSide(
//                           color: isDark
//                               ? const Color(0xFF4D4E63)
//                               : const Color(0xFFD8D7D7),
//                         ),
//                       ),
//                     ),
//                     child: Row(
//                       children: [
//                         _DataCell("#${order.orderId}"),
//                         _DataCell(order.orderType),
//                         _DataCell(
//                           DateFormat('dd-MM-yyyy').format(order.completedAt),
//                         ),
//                         const SizedBox(width: 10),
//                         Expanded(
//                           child: GestureDetector(
//                             onTap: () {},
//                             behavior: HitTestBehavior.opaque,
//                             child: DropdownButtonHideUnderline(
//                               child: Builder(
//                                 builder: (context) {
//                                   final List<String> itemsList = [
//                                     order.transactionId.toString(),
//                                     ...transactionIdOptions
//                                         .map((e) => e.toString()),
//                                   ].toSet().toList();
//
//                                   // ✅ Show only first 2 IDs in display
//                                   String displayText = "";
//
//                                   if (itemsList.length == 1) {
//                                     displayText = itemsList[0];
//                                   } else if (itemsList.length == 2) {
//                                     displayText =
//                                     "${itemsList[0]}, ${itemsList[1]}";
//                                   } else if (itemsList.length > 2) {
//                                     displayText =
//                                     "${itemsList[0]}, ${itemsList[1]}...";
//                                   }
//                                   return DropdownButton<String>(
//                                     value: selectedTxnPerOrder[order.orderId] ?? itemsList.first,
//                                     isDense: true,
//                                     isExpanded: true,
//                                     icon: const SizedBox.shrink(),
//                                     onChanged: (value) {
//                                       setState(() {
//                                         selectedTxnPerOrder[order.orderId] =
//                                         value!;
//                                       });
//                                     },
//                                     selectedItemBuilder: (context) {
//                                       return itemsList.map((e) {
//                                         return Align(
//                                           alignment: Alignment.centerLeft,
//                                           child: Text(
//                                             displayText,
//                                             style: const TextStyle(
//                                                 fontSize: 14),
//                                             overflow: TextOverflow.ellipsis,
//                                           ),
//                                         );
//                                       }).toList();
//                                     },
//                                     items: itemsList.map((txn) {
//                                       return DropdownMenuItem<String>(
//                                         value: txn,
//                                         child: Text(
//                                           txn,
//                                           style:
//                                           const TextStyle(fontSize: 12),
//                                         ),
//                                       );
//                                     }).toList(),
//                                   );
//                                 },
//                               ),
//                             ),
//                           ),
//                         ),
//                         _DataCell(order.paymentMethod),
//                         _DataCell(
//                             '${order.amount < 0 ? '-' : ''}\$${order.amount.abs().toStringAsFixed(2)}'),
//                         _DataCell(
//                             '${order.tax < 0 ? '-' : ''}\$${order.tax.abs().toStringAsFixed(2)}'),
//                         _DataCell(
//                             '${order.discount < 0 ? '-' : ''}\$${order.discount.abs().toStringAsFixed(2)}'),
//                         _DataCell(
//                             '${order.total < 0 ? '-' : ''}\$${order.total.abs().toStringAsFixed(2)}'),
//                         const _StatusCell(),
//                       ],
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // ================= PAGINATION =================
//   Widget _buildPagination() {
//     final int totalItems = filteredOrders.length;
//     final int totalPages = _totalPages;
//
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.end,
//         children: [
//           const Text("Rows per page:"),
//           const SizedBox(width: 8),
//
//           // ---------------- ROWS PER PAGE ----------------
//           Container(
//             padding: const EdgeInsets.symmetric(horizontal: 8.0),
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(8.0),
//               border: Border.all(color: Colors.grey.shade400),
//             ),
//             child: DropdownButton<int>(
//               value: _rowsPerPage,
//               underline: const SizedBox.shrink(),
//               items: _rowsPerPageOptions.map((int value) {
//                 return DropdownMenuItem<int>(
//                   value: value,
//                   child: Text(value.toString()),
//                 );
//               }).toList(),
//               onChanged: (int? newValue) {
//                 if (newValue != null) {
//                   setState(() {
//                     _rowsPerPage = newValue;
//                     _currentPage = 1;
//                     _loadPage(1);
//                   });
//                 }
//               },
//             ),
//           ),
//
//           const SizedBox(width: 24),
//
//           // ---------------- PAGE INFO ----------------
//           Text(
//             totalItems == 0
//                 ? '0-0 of 0'
//                 : '${(_currentPage - 1) * _rowsPerPage + 1}'
//                 '-${(_currentPage * _rowsPerPage) > totalItems ? totalItems : (_currentPage * _rowsPerPage)}'
//                 ' of $totalItems',
//           ),
//
//           const SizedBox(width: 24),
//
//           // ---------------- FIRST PAGE ----------------
//           IconButton(
//             icon: const Icon(Icons.first_page),
//             onPressed: _currentPage == 1 || totalItems == 0
//                 ? null
//                 : () => _loadPage(1),
//           ),
//
//           // ---------------- PREVIOUS PAGE ----------------
//           IconButton(
//             icon: const Icon(Icons.chevron_left),
//             onPressed: _currentPage == 1 || totalItems == 0
//                 ? null
//                 : () => _loadPage(_currentPage - 1),
//           ),
//
//           // ---------------- NEXT PAGE ----------------
//           IconButton(
//             icon: const Icon(Icons.chevron_right),
//             onPressed: _currentPage == totalPages || totalItems == 0
//                 ? null
//                 : () => _loadPage(_currentPage + 1),
//           ),
//
//           // ---------------- LAST PAGE ----------------
//           IconButton(
//             icon: const Icon(Icons.last_page),
//             onPressed: _currentPage == totalPages || totalItems == 0
//                 ? null
//                 : () => _loadPage(totalPages),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _pageButton(int page) {
//     final bool selected = _currentPage == page;
//
//     return InkWell(
//       onTap: () {
//         setState(() {
//           _currentPage = page;
//         });
//       },
//       child: Container(
//         margin: const EdgeInsets.symmetric(horizontal: 4),
//         padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//         decoration: BoxDecoration(
//           color: selected ? Colors.red : Colors.transparent,
//           borderRadius: BorderRadius.circular(6),
//           border: Border.all(color: Colors.red),
//         ),
//         child: Text(
//           page.toString(),
//           style: TextStyle(
//             color: selected ? Colors.white : Colors.red,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// /// ================= SHARED CELLS =================
//
// class _HeaderCell extends StatelessWidget {
//   final String text;
//   const _HeaderCell(this.text);
//
//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//       child: Text(
//         text,
//         style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
//       ),
//     );
//   }
// }
//
// class _DataCell extends StatelessWidget {
//   final String text;
//   const _DataCell(this.text);
//
//   @override
//   Widget build(BuildContext context) {
//     return Expanded(child: Text(text));
//   }
// }
//
// class _StatusCell extends StatelessWidget {
//   const _StatusCell();
//
//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
//         decoration: BoxDecoration(
//           color: Colors.green.shade100,
//           borderRadius: BorderRadius.circular(20),
//         ),
//         child: const Text(
//           "Completed",
//           style: TextStyle(color: Colors.green),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

import '../../Constants/text.dart';
import '../../Helper/Extentions/theme_notifier.dart';
import '../../Preferences/pinaka_preferences.dart';
import '../../Widgets/widget_navigation_bar.dart' as custom_widgets;
import '../../Widgets/widget_topbar.dart';
import '../Database/db_helper.dart';
import '../Database/user_db_helper.dart';
import '../Helper/Extentions/nav_layout_manager.dart';
import '../Helper/url_helper.dart';
import '../Models/Orders/refund_orderlist_model.dart';
import '../Repositories/Orders/refund_validation_repository.dart';
import '../Widgets/refund_checkin_popup.dart';
import '../Blocs/Orders/refund_validation_bloc.dart';

enum SidebarPosition { left, right, bottom }

enum OrderPanelPosition { left, right }

List<String> allData = List.generate(27, (i) => "Item ${i + 1}");

class CompletedOrdersScreen extends StatefulWidget {
  final int lastSelectedIndex;
  const CompletedOrdersScreen({super.key, required this.lastSelectedIndex});

  @override
  State<CompletedOrdersScreen> createState() => _CompletedOrdersScreenState();
}

class _CompletedOrdersScreenState extends State<CompletedOrdersScreen>
    with WidgetsBindingObserver, LayoutSelectionMixin {

  int _selectedSidebarIndex = 5;
  int _currentPage = 1;
  int itemsPerPage = 10;
  final List<int> _rowsPerPageOptions = [10, 20, 50, 100];
  int _rowsPerPage = 10;
  DateTime? selectedDate;
  List<int> quantities = [];
  DateTime? _startDate;
  DateTime? _endDate;
  bool _isDateRangeApplied = false;
  static bool isActive = false;

  List<CompletedOrder> _allOrders = [];
  List<CompletedOrder> filteredOrders = [];
  List<CompletedOrder> _pagedOrders = [];
  List<CompletedOrder> _visibleOrders = [];

  // ✅ NEW: Loading and error states
  bool _isLoading = false;
  String? _errorMessage;

  // ✅ NEW: Cache management
  static List<CompletedOrder> _cachedOrders = [];
  static DateTime? _lastFetchTime;
  static const Duration _cacheDuration = Duration(minutes: 5);
  static Set<int> _cachedOrderIds = {};
  static bool _isInitialLoad = true;

  int get _totalPages {
    final pages = _rowsPerPage > 0 ? (filteredOrders.length / _rowsPerPage).ceil() : 1;
    return pages == 0 ? 1 : pages;
  }

  TextEditingController searchController = TextEditingController();
  String selectedStatus = 'Completed';
  String? selectedTransactionId;
  List<String> transactionIds = [];
  Map<int, String?> selectedTxnPerOrder = {};
  List<String> transactionIdOptions = [];
  bool _isModeChangePending = false;
  bool _isNavigatingAway = false;

  List<CompletedOrder> _orders = [];

  String _todayStart() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 0, 0, 0);
    return start.toIso8601String();
  }

  String _todayEnd() {
    final now = DateTime.now();
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59);
    return end.toIso8601String();
  }

  void _paginate() {
    final int totalPages = _totalPages;
    if (_currentPage > totalPages) {
      _currentPage = totalPages;
    }
    if (_currentPage < 1) {
      _currentPage = 1;
    }

    final startIndex = (_currentPage - 1) * _rowsPerPage;
    final endIndex = startIndex + _rowsPerPage;

    if (startIndex >= filteredOrders.length) {
      _pagedOrders = [];
    } else {
      _pagedOrders = filteredOrders.sublist(
        startIndex,
        endIndex > filteredOrders.length ? filteredOrders.length : endIndex,
      );
    }
  }

  void _loadPage(int page) {
    setState(() {
      _currentPage = page;
      _paginate();
    });
  }

  @override
  void deactivate() {
    _isNavigatingAway = true;
    super.deactivate();
  }

  void _updatePagination() {
    final startIndex = (_currentPage - 1) * itemsPerPage;
    final endIndex = startIndex + itemsPerPage;

    setState(() {
      _pagedOrders = filteredOrders.sublist(
        startIndex,
        endIndex > filteredOrders.length ? filteredOrders.length : endIndex,
      );
    });
  }

  @override
  void initState() {
    super.initState();
    _selectedSidebarIndex = widget.lastSelectedIndex;
    _loadCompletedOrders();
  }

  @override
  void dispose() {
    _isNavigatingAway = true;
    searchController.dispose();
    super.dispose();
  }

  // ✅ MODIFIED: Smart loading with caching and incremental updates
  Future<void> _loadCompletedOrders() async {
    // Check if cache is valid and we have data
    final bool shouldUseCache = _cachedOrders.isNotEmpty &&
        _lastFetchTime != null &&
        DateTime.now().difference(_lastFetchTime!) < _cacheDuration;

    if (shouldUseCache && !_isInitialLoad) {
      if (kDebugMode) {
        debugPrint("📦 Using cached orders (${_cachedOrders.length} items)");
      }
      setState(() {
        _allOrders = List.from(_cachedOrders);
        filteredOrders = List.from(_cachedOrders);
        _updateTransactionIds();
        _currentPage = 1;
        _paginate();
      });

      // Fetch latest updates in background
      _fetchLatestOrdersInBackground();
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Get last known order ID for incremental updates
      int? lastOrderId = _cachedOrders.isNotEmpty ? _cachedOrders.first.orderId : null;

      final orders = await _fetchCompletedOrders(
        page: 1,
        perPage: 100, // Load all orders at once for client-side filtering
        lastOrderId: lastOrderId,
      );

      if (kDebugMode) {
        debugPrint("✅ Fetched ${orders.length} completed orders");
      }

      // Merge with cache - update only new/changed orders
      _mergeOrdersWithCache(orders);

      setState(() {
        _allOrders = List.from(_cachedOrders);
        filteredOrders = List.from(_cachedOrders);
        _updateTransactionIds();
        _currentPage = 1;
        _isLoading = false;
        _isInitialLoad = false;
        _paginate();
      });

    } catch (e) {
      // If error occurs but we have cached data, use it
      if (_cachedOrders.isNotEmpty) {
        if (kDebugMode) {
          debugPrint("⚠️ Error loading, using cached data: $e");
        }
        setState(() {
          _allOrders = List.from(_cachedOrders);
          filteredOrders = List.from(_cachedOrders);
          _updateTransactionIds();
          _currentPage = 1;
          _isLoading = false;
          _errorMessage = null;
          _paginate();
        });
      } else {
        setState(() {
          _errorMessage = e.toString();
          _isLoading = false;
        });
        if (kDebugMode) {
          debugPrint("❌ Error loading completed orders: $e");
        }
      }
    }
  }

  // ✅ NEW: Background fetch for latest updates
  void _fetchLatestOrdersInBackground() {
    Future.delayed(const Duration(milliseconds: 500), () async {
      try {
        int? lastOrderId = _cachedOrders.isNotEmpty ? _cachedOrders.first.orderId : null;
        final newOrders = await _fetchCompletedOrders(
          page: 1,
          perPage: 50, // Fetch only recent orders
          lastOrderId: lastOrderId,
        );

        if (newOrders.isNotEmpty && mounted) {
          _mergeOrdersWithCache(newOrders);
          setState(() {
            _allOrders = List.from(_cachedOrders);
            filteredOrders = List.from(_cachedOrders);
            _updateTransactionIds();
            _paginate();
          });
          if (kDebugMode) {
            debugPrint("🔄 Background update: Added ${newOrders.length} new orders");
          }
        }
      } catch (e) {
        if (kDebugMode) {
          debugPrint("⚠️ Background update failed: $e");
        }
      }
    });
  }

  // ✅ MODIFIED: Merge orders with cache - now sorts by completedAt (latest first)
  void _mergeOrdersWithCache(List<CompletedOrder> newOrders) {
    // Create a map of existing orders by ID
    final Map<int, CompletedOrder> existingOrderMap = {
      for (var order in _cachedOrders) order.orderId: order
    };

    // Add or update orders
    for (var order in newOrders) {
      // Check if this is a newer version of an existing order
      if (existingOrderMap.containsKey(order.orderId)) {
        final existing = existingOrderMap[order.orderId]!;
        // Compare timestamps to determine if update is needed
        if (order.completedAt.isAfter(existing.completedAt)) {
          existingOrderMap[order.orderId] = order;
        }
      } else {
        // New order - add it
        existingOrderMap[order.orderId] = order;
      }
    }

    // Convert back to list and sort by completedAt (newest first)
    _cachedOrders = existingOrderMap.values.toList()
      ..sort((a, b) => b.completedAt.compareTo(a.completedAt));

    _cachedOrderIds = _cachedOrders.map((o) => o.orderId).toSet();
    _lastFetchTime = DateTime.now();
  }

  // ✅ NEW: Update transaction IDs
  void _updateTransactionIds() {
    transactionIds = _allOrders
        .map((o) => o.transactionId)
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList();
  }

  // ✅ MODIFIED: Direct fetch method with incremental support
  Future<List<CompletedOrder>> _fetchCompletedOrders({
    required int page,
    int? perPage,
    int? authorId,
    String? from,
    String? to,
    int? lastOrderId, // ✅ NEW: For incremental updates
  }) async {
    final token = await _getTokenFromDb();

    // ✅ Build query parameters dynamically
    final queryParams = {
      'page': page.toString(),
      if (perPage != null) 'per_page': perPage.toString(),
      if (authorId != null) 'author': authorId.toString(),
      if (from != null && from.isNotEmpty) 'after': from,
      if (to != null && to.isNotEmpty) 'before': to,
      // ✅ NEW: Add incremental parameter if provided
      if (lastOrderId != null) 'since_id': lastOrderId.toString(),
    };

    final uri = Uri.parse(
      '${UrlHelper.baseUrl}pinaka-pos/v1/orders/completed-orders',
    ).replace(queryParameters: queryParams);

    final response = await http.get(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/json',
      },
    );

    if (kDebugMode) {
      print("completed orders Status Code: ${response.statusCode}");
      print("Body: ${response.body}");
    }

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to load completed orders (status: ${response.statusCode})',
      );
    }

    final decoded = jsonDecode(response.body);
    if (kDebugMode) {
      print("DECODED JSON:");
      debugPrint(decoded.toString());
    }

    // ✅ Safe parsing
    if (decoded == null ||
        decoded['orders_data'] == null ||
        decoded['orders_data'] is! List) {
      return [];
    }

    final List ordersList = decoded['orders_data'];

    return ordersList
        .map((e) => CompletedOrder.fromJson(e))
        .toList();
  }

  // ✅ Helper to get token from DB
  Future<String> _getTokenFromDb() async {
    final db = await DBHelper.instance.database;

    final result = await db.query(
      AppDBConst.userTable,
      where:
      '${AppDBConst.userToken} IS NOT NULL AND ${AppDBConst.userToken} != ""',
      orderBy: '${AppDBConst.userId} DESC',
      limit: 1,
    );

    if (result.isEmpty) {
      throw Exception('No active user token found in database');
    }

    final token = result.first[AppDBConst.userToken] as String;

    if (kDebugMode) {
      print('Using JWT token: ${token.substring(0, 20)}...');
    }

    return token;
  }

  // ✅ FIX: Helper to compute sidebar position fresh from notifier
  SidebarPosition _getSidebarPosition(String layout) {
    if (layout == SharedPreferenceTextConstants.navRightOrderLeft) return SidebarPosition.right;
    if (layout == SharedPreferenceTextConstants.navBottomOrderLeft) return SidebarPosition.bottom;
    if (layout == SharedPreferenceTextConstants.navBottomOrderRight) return SidebarPosition.bottom;
    return SidebarPosition.left;
  }

  // ✅ FIX: Helper to compute order panel position fresh from notifier
  OrderPanelPosition _getOrderPanelPosition(String layout) {
    if (layout == SharedPreferenceTextConstants.navRightOrderLeft) return OrderPanelPosition.left;
    if (layout == SharedPreferenceTextConstants.navBottomOrderLeft) return OrderPanelPosition.left;
    if (layout == SharedPreferenceTextConstants.navBottomOrderRight) return OrderPanelPosition.right;
    return OrderPanelPosition.right;
  }

  /// ✅ FINAL SAFE MODE CHANGE HANDLER
  void _handleModeChange() async {
    if (_isNavigatingAway || _isModeChangePending) {
      print("🚫 [Refund] Mode change BLOCKED - navigating away");
      return;
    }

    _isModeChangePending = true;
    print("🔄 [Refund] Mode toggle requested");

    final String currentLayout = PinakaPreferences.layoutSelectionNotifier.value;
    final SidebarPosition currentSidebar = _getSidebarPosition(currentLayout);
    final OrderPanelPosition currentOrderPanel = _getOrderPanelPosition(currentLayout);

    String newLayout;
    if (currentSidebar == SidebarPosition.left) {
      newLayout = SharedPreferenceTextConstants.navRightOrderLeft;
    } else if (currentSidebar == SidebarPosition.right) {
      newLayout = SharedPreferenceTextConstants.navBottomOrderLeft;
    } else {
      newLayout = currentOrderPanel == OrderPanelPosition.left
          ? SharedPreferenceTextConstants.navBottomOrderRight
          : SharedPreferenceTextConstants.navLeftOrderRight;
    }

    print("🔄 [Refund] Changing mode to: $newLayout");

    PinakaPreferences.layoutSelectionNotifier.value = newLayout;

    await UserDbHelper().saveUserSettings(
      {AppDBConst.layoutSelection: newLayout},
      modeChange: true,
    );

    // Reset after small delay
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) _isModeChangePending = false;
    });
    if (mounted) {
      setState(() {});
    }
  }

  // ✅ Refresh method
  Future<void> _refreshOrders() async {
    // Force refresh by clearing cache
    _lastFetchTime = null;
    _isInitialLoad = true;
    await _loadCompletedOrders();
  }

  @override
  Widget build(BuildContext context) {
    final themeHelper = Provider.of<ThemeNotifier>(context);

    return ValueListenableBuilder<String>(
      valueListenable: PinakaPreferences.layoutSelectionNotifier,
      builder: (context, layout, _) {
        final SidebarPosition sidebarPosition = _getSidebarPosition(layout);
        final OrderPanelPosition orderPanelPosition = _getOrderPanelPosition(layout);

        return Scaffold(
          body: Column(
            children: [
              /// 🔹 TOP BAR (same as Orders screen)
              TopBar(
                screen: Screen.ORDERS,
                onModeChanged: _handleModeChange,
              ),
              const Divider(height: 1, thickness: 0.4),

              /// 🔹 MAIN CONTENT
              Expanded(
                child: Row(
                  children: [
                    /// 🔹 LEFT SIDEBAR
                    if (sidebarPosition == SidebarPosition.left)
                      custom_widgets.NavigationBar(
                        selectedSidebarIndex: _selectedSidebarIndex,
                        isVertical: true,
                        onSidebarItemSelected: (index) {
                          setState(() => _selectedSidebarIndex = index);
                        },
                      ),

                    /// 🔹 CENTER CONTENT (Completed Orders Table)
                    Expanded(
                      child: _buildContent(themeHelper),
                    ),

                    /// 🔹 RIGHT SIDEBAR
                    if (sidebarPosition == SidebarPosition.right)
                      custom_widgets.NavigationBar(
                        selectedSidebarIndex: _selectedSidebarIndex,
                        isVertical: true,
                        onSidebarItemSelected: (index) {
                          setState(() => _selectedSidebarIndex = index);
                        },
                      ),
                  ],
                ),
              ),

              /// 🔹 BOTTOM SIDEBAR
              if (sidebarPosition == SidebarPosition.bottom)
                custom_widgets.NavigationBar(
                  selectedSidebarIndex: _selectedSidebarIndex,
                  isVertical: false,
                  onSidebarItemSelected: (index) {
                    setState(() => _selectedSidebarIndex = index);
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  // ✅ NEW: Content builder replacing BlocConsumer
  Widget _buildContent(ThemeNotifier themeHelper) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _errorMessage!,
              style: const TextStyle(color: Colors.red),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _refreshOrders,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (filteredOrders.isEmpty) {
      return const Center(
        child: Text("No completed orders found"),
      );
    }

    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: themeHelper.themeMode == ThemeMode.dark
            ? ThemeNotifier.primaryBackground
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 6,
          ),
        ],
      ),
      child: Column(
        children: [
          _buildHeader(),
          const SizedBox(height: 12),
          Expanded(
            child: _buildOrderTable(themeHelper),
          ),
          const SizedBox(height: 8),
          _buildPagination(),
        ],
      ),
    );
  }

  // ================= HEADER =================

  Widget _buildHeader() {
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      children: [
        const Text(
          "Completed Order List",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const Spacer(),
        Container(
          width: 200,
          height: 35,
          decoration: BoxDecoration(
            color: isDark
                ? const Color(0xFF29313F)
                : Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 6,
                spreadRadius: 1,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: TextField(
            controller: searchController,
            textAlignVertical: TextAlignVertical.center,
            onChanged: (value) {
              setState(() {
                if (value.isEmpty) {
                  filteredOrders = _allOrders;
                } else {
                  filteredOrders = _allOrders.where((order) {
                    return order.orderId
                        .toString()
                        .toLowerCase()
                        .contains(value.toLowerCase());
                  }).toList();
                }

                _currentPage = 1;
                _paginate();
              });
            },
            decoration: InputDecoration(
              hintText: "Search Order ID",
              hintStyle: TextStyle(
                fontFamily: "Inter",
                fontSize: 13,
                fontWeight: FontWeight.w400,
                color: isDark ? Colors.white : const Color(0xFF999393),
              ),
              prefixIcon: Icon(
                Icons.search,
                color: isDark ? Colors.white : const Color(0xFF999393),
                size: 18,
              ),
              suffixIcon: searchController.text.isNotEmpty
                  ? IconButton(
                icon: Icon(
                  Icons.close,
                  color: isDark
                      ? Colors.white
                      : const Color(0xFF6B7280),
                  size: 18,
                ),
                onPressed: () {
                  searchController.clear();
                  setState(() {
                    filteredOrders = _allOrders;
                    _currentPage = 1;
                    _paginate();
                  });
                },
              )
                  : null,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  vertical: 0),
              isDense: true,
            ),
          ),
        ),
        const SizedBox(width: 18),
        Row(
          children: [
            const SizedBox(width: 8),

            // CALENDAR ICON FILTER
            InkWell(
              onTap: _openDateRangePickerDialog,
              child: Container(
                padding: const EdgeInsets.all(7),
                child: SvgPicture.asset(
                  'assets/svg/filter_calendar.svg',
                  width: 32,
                  height: 32,
                  colorFilter: ColorFilter.mode(
                    _isDateRangeApplied
                        ? Colors.redAccent
                        : Theme.of(context).colorScheme.onSurface,
                    BlendMode.srcIn,
                  ),
                ),
              ),
            ),
          ],
        )
      ],
    );
  }

  void _openDateRangePickerDialog() {
    final themeHelper = Provider.of<ThemeNotifier>(context, listen: false);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: themeHelper.themeMode == ThemeMode.dark
              ? ThemeNotifier.secondaryBackground
              : null,
          title: const Text("Select Date Range"),
          content: SizedBox(
            height: 400,
            width: 350,
            child: SfDateRangePicker(
              selectionMode: DateRangePickerSelectionMode.range,
              showActionButtons: true,
              onSelectionChanged: _onDateRangeSelectionChanged,
              initialSelectedRange: _startDate != null && _endDate != null
                  ? PickerDateRange(_startDate, _endDate)
                  : null,
              onSubmit: (value) => Navigator.pop(context),
              onCancel: () => Navigator.pop(context),
            ),
          ),
        );
      },
    );
  }

  void _onDateRangeSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    if (args.value is PickerDateRange) {
      final range = args.value as PickerDateRange;

      setState(() {
        _startDate = range.startDate;
        _endDate = range.endDate ?? range.startDate;

        _isDateRangeApplied = _startDate != null && _endDate != null;

        _applyDateFilter();
      });
    }
  }

  void _applyDateFilter() {
    if (!_isDateRangeApplied || _startDate == null || _endDate == null) {
      filteredOrders = _allOrders;
    } else {
      filteredOrders = _allOrders.where((order) {
        final orderDate = order.completedAt;

        final dateOnly =
        DateTime(orderDate.year, orderDate.month, orderDate.day);

        final start =
        DateTime(_startDate!.year, _startDate!.month, _startDate!.day);

        final end = DateTime(_endDate!.year, _endDate!.month, _endDate!.day);

        return dateOnly.isAfter(start.subtract(const Duration(days: 1))) &&
            dateOnly.isBefore(end.add(const Duration(days: 1)));
      }).toList();
    }

    _currentPage = 1;
    _paginate();
  }

  // ================= TABLE =================

  Widget _buildOrderTable(ThemeNotifier themeHelper) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: themeHelper.themeMode == ThemeMode.dark
            ? const Color(0xFF201F29)
            : const Color(0xFFF9F9F9),
      ),
      child: Column(
        children: [
          /// 🔹 TABLE HEADER
          Container(
            padding: const EdgeInsets.only(
              left: 8,
              right: 0,
              top: 14,
              bottom: 14,
            ),
            decoration: BoxDecoration(
              color: themeHelper.themeMode == ThemeMode.dark
                  ? const Color(0xFF29313F)
                  : const Color(0xFF6F6F70),
              borderRadius:
              const BorderRadius.vertical(top: Radius.circular(10)),
            ),
            child: Row(
              children: const [
                SizedBox(width: 10),
                _HeaderCell("Order ID"),
                _HeaderCell("Order Type"),
                _HeaderCell("Date"),
                _HeaderCell("Transaction ID"),
                _HeaderCell("Payment Type"),
                _HeaderCell("Amount"),
                _HeaderCell("Item Tax"),
                _HeaderCell("Discount"),
                _HeaderCell("Total"),
                _HeaderCell("Status"),
              ],
            ),
          ),

          /// 🔹 TABLE BODY
          Expanded(
            child: ListView.builder(
              itemCount: _pagedOrders.length,
              itemBuilder: (context, index) {
                final order = _pagedOrders[index];

                return InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (dialogContext) {
                        return BlocProvider(
                          create: (_) => RefundValidationBloc(
                            repository: RefundValidationRepository(
                              baseUrl:
                              "https://merchantretail.alektasolutions.com",
                            ),
                          ),
                          child: PinCheckInDialog(order: order),
                        );
                      },
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.only(
                      left: 10,
                      right: 10,
                      top: 10,
                      bottom: 10,
                    ),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF212231) : Colors.white,
                      border: Border(
                        bottom: BorderSide(
                          color: isDark
                              ? const Color(0xFF4D4E63)
                              : const Color(0xFFD8D7D7),
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        _DataCell("#${order.orderId}"),
                        _DataCell(order.orderType),
                        _DataCell(
                          DateFormat('dd-MM-yyyy').format(order.completedAt),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {},
                            behavior: HitTestBehavior.opaque,
                            child: DropdownButtonHideUnderline(
                              child: Builder(
                                builder: (context) {
                                  final List<String> itemsList = [
                                    order.transactionId.toString(),
                                    ...transactionIdOptions
                                        .map((e) => e.toString()),
                                  ].toSet().toList();

                                  // ✅ Show only first 2 IDs in display
                                  String displayText = "";

                                  if (itemsList.length == 1) {
                                    displayText = itemsList[0];
                                  } else if (itemsList.length == 2) {
                                    displayText =
                                    "${itemsList[0]}, ${itemsList[1]}";
                                  } else if (itemsList.length > 2) {
                                    displayText =
                                    "${itemsList[0]}, ${itemsList[1]}...";
                                  }
                                  return DropdownButton<String>(
                                    value: selectedTxnPerOrder[order.orderId] ?? itemsList.first,
                                    isDense: true,
                                    isExpanded: true,
                                    icon: const SizedBox.shrink(),
                                    onChanged: (value) {
                                      setState(() {
                                        selectedTxnPerOrder[order.orderId] =
                                        value!;
                                      });
                                    },
                                    selectedItemBuilder: (context) {
                                      return itemsList.map((e) {
                                        return Align(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            displayText,
                                            style: const TextStyle(
                                                fontSize: 14),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        );
                                      }).toList();
                                    },
                                    items: itemsList.map((txn) {
                                      return DropdownMenuItem<String>(
                                        value: txn,
                                        child: Text(
                                          txn,
                                          style:
                                          const TextStyle(fontSize: 12),
                                        ),
                                      );
                                    }).toList(),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                        _DataCell(order.paymentMethod),
                        _DataCell(
                            '${order.amount < 0 ? '-' : ''}\$${order.amount.abs().toStringAsFixed(2)}'),
                        _DataCell(
                            '${order.tax < 0 ? '-' : ''}\$${order.tax.abs().toStringAsFixed(2)}'),
                        _DataCell(
                            '${order.discount < 0 ? '-' : ''}\$${order.discount.abs().toStringAsFixed(2)}'),
                        _DataCell(
                            '${order.total < 0 ? '-' : ''}\$${order.total.abs().toStringAsFixed(2)}'),
                        const _StatusCell(),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ================= PAGINATION =================
  Widget _buildPagination() {
    final int totalItems = filteredOrders.length;
    final int totalPages = _totalPages;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const Text("Rows per page:"),
          const SizedBox(width: 8),

          // ---------------- ROWS PER PAGE ----------------
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(color: Colors.grey.shade400),
            ),
            child: DropdownButton<int>(
              value: _rowsPerPage,
              underline: const SizedBox.shrink(),
              items: _rowsPerPageOptions.map((int value) {
                return DropdownMenuItem<int>(
                  value: value,
                  child: Text(value.toString()),
                );
              }).toList(),
              onChanged: (int? newValue) {
                if (newValue != null) {
                  setState(() {
                    _rowsPerPage = newValue;
                    _currentPage = 1;
                    _loadPage(1);
                  });
                }
              },
            ),
          ),

          const SizedBox(width: 24),

          // ---------------- PAGE INFO ----------------
          Text(
            totalItems == 0
                ? '0-0 of 0'
                : '${(_currentPage - 1) * _rowsPerPage + 1}'
                '-${(_currentPage * _rowsPerPage) > totalItems ? totalItems : (_currentPage * _rowsPerPage)}'
                ' of $totalItems',
          ),

          const SizedBox(width: 24),

          // ---------------- FIRST PAGE ----------------
          IconButton(
            icon: const Icon(Icons.first_page),
            onPressed: _currentPage == 1 || totalItems == 0
                ? null
                : () => _loadPage(1),
          ),

          // ---------------- PREVIOUS PAGE ----------------
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: _currentPage == 1 || totalItems == 0
                ? null
                : () => _loadPage(_currentPage - 1),
          ),

          // ---------------- NEXT PAGE ----------------
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: _currentPage == totalPages || totalItems == 0
                ? null
                : () => _loadPage(_currentPage + 1),
          ),

          // ---------------- LAST PAGE ----------------
          IconButton(
            icon: const Icon(Icons.last_page),
            onPressed: _currentPage == totalPages || totalItems == 0
                ? null
                : () => _loadPage(totalPages),
          ),
        ],
      ),
    );
  }

  Widget _pageButton(int page) {
    final bool selected = _currentPage == page;

    return InkWell(
      onTap: () {
        setState(() {
          _currentPage = page;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? Colors.red : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: Colors.red),
        ),
        child: Text(
          page.toString(),
          style: TextStyle(
            color: selected ? Colors.white : Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

/// ================= SHARED CELLS =================

class _HeaderCell extends StatelessWidget {
  final String text;
  const _HeaderCell(this.text);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _DataCell extends StatelessWidget {
  final String text;
  const _DataCell(this.text);

  @override
  Widget build(BuildContext context) {
    return Expanded(child: Text(text));
  }
}

class _StatusCell extends StatelessWidget {
  const _StatusCell();

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.green.shade100,
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Text(
          "Completed",
          style: TextStyle(color: Colors.green),
        ),
      ),
    );
  }
}