// import 'package:flutter/material.dart';
//
// import 'indigo_category_model.dart';
// import 'indigo_category_repository.dart';
//
// class IndigoCategoryScreen extends StatefulWidget {
//   const IndigoCategoryScreen({super.key});
//
//   @override
//   State<IndigoCategoryScreen> createState() =>
//       _IndigoCategoryScreenState();
// }
//
// class _IndigoCategoryScreenState
//     extends State<IndigoCategoryScreen> {
//
//   final IndigoCategoryRepository repository =
//   IndigoCategoryRepository();
//
//   late Future<List<IndigoCategoryModel>> indigoCategories;
//
//   @override
//   void initState() {
//     super.initState();
//     indigoCategories = repository.indigoFetchCategories();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Indigo Categories"),
//       ),
//
//       body: FutureBuilder<List<IndigoCategoryModel>>(
//         future: indigoCategories,
//         builder: (context, snapshot) {
//
//           if (snapshot.connectionState ==
//               ConnectionState.waiting) {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           }
//
//           if (snapshot.hasError) {
//             return Center(
//               child: Text(snapshot.error.toString()),
//             );
//           }
//
//           final categories = snapshot.data!;
//
//           return ListView.builder(
//             itemCount: categories.length,
//             itemBuilder: (context, index) {
//
//               final category = categories[index];
//
//               return Card(
//                 margin: const EdgeInsets.all(10),
//
//                 child: ListTile(
//
//                   leading: Image.network(
//                     category.image,
//                     width: 50,
//                     height: 50,
//                     fit: BoxFit.cover,
//                   ),
//
//                   title: Text(category.name),
//
//                   subtitle: Text(
//                     "Items: ${category.count}",
//                   ),
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }