// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/foundation.dart';
//
// import '../Database/db_helper.dart';
// import 'indigo_category_model.dart';
//
// class IndigoCategoryRepository {
//
//   Future<List<IndigoCategoryModel>> indigoFetchCategories() async {
//
//     final token = await _getTokenFromDb();
//
//     final url = Uri.parse(
//         "https://indigo.alekyatechsolutions.com/wp-json/pinaka-pos/v1/categories?page=1&per_page=100&hide_empty=true&parent=105"
//     );
//
//     final response = await http.get(
//       url,
//       headers: {
//         "Authorization": "Bearer $token",
//       },
//     );
//
//     if (response.statusCode == 200) {
//
//       List data = jsonDecode(response.body);
//
//       return data
//           .map((json) => IndigoCategoryModel.fromJson(json))
//           .toList();
//
//     } else {
//       throw Exception("Failed to load categories");
//     }
//   }
//
//   Future<String> _getTokenFromDb() async {
//     final db = await DBHelper.instance.database;
//
//     final result = await db.query(
//       AppDBConst.userTable,
//       where:
//       '${AppDBConst.userToken} IS NOT NULL AND ${AppDBConst.userToken} != ""',
//       orderBy: '${AppDBConst.userId} DESC',
//       limit: 1,
//     );
//
//     if (result.isEmpty) {
//       throw Exception('No active user token found in database');
//     }
//
//     final token = result.first[AppDBConst.userToken] as String;
//
//     if (kDebugMode) {
//       print('Using JWT token: ${token.substring(0, 20)}...');
//     }
//
//     return token;
//   }
// }