// class IndigoCategoryModel {
//   final int id;
//   final String name;
//   final String slug;
//   final int parent;
//   final String description;
//   final int count;
//   final String image;
//
//   IndigoCategoryModel({
//     required this.id,
//     required this.name,
//     required this.slug,
//     required this.parent,
//     required this.description,
//     required this.count,
//     required this.image,
//   });
//
//   factory IndigoCategoryModel.fromJson(Map<String, dynamic> json) {
//     return IndigoCategoryModel(
//       id: json['id'],
//       name: json['name'],
//       slug: json['slug'],
//       parent: json['parent'],
//       description: json['description'] ?? '',
//       count: json['count'],
//       image: json['image'] ?? '',
//     );
//   }
// }