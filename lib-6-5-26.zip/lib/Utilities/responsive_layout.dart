import 'dart:math';
import 'package:flutter/material.dart';

class ResponsiveLayout {
  static MediaQueryData? _mediaQueryData;

  static double? screenWidth;
  static double? screenHeight;
  static double? blockSizeHorizontal;
  static double? blockSizeVertical;
  static double? _safeAreaHorizontal;
  static double? _safeAreaVertical;
  static double? safeBlockHorizontal;
  static double? safeBlockVertical;
  static double? devicePixelRatio;
  static double? textScaleFactor;
  static Orientation? orientation;
  static double? aspectRatio;

  static bool _initialized = false;

  // Target resolution constants
  static const double targetWidth = 1280.0;
  static const double targetHeight = 720.0;

  /// Manual init (still supported)
  static void init(BuildContext context) {
    _setup(context);
  }

  /// Internal setup
  static void _setup(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);

    screenWidth = _mediaQueryData!.size.width;
    screenHeight = _mediaQueryData!.size.height;
    devicePixelRatio = _mediaQueryData!.devicePixelRatio;
    textScaleFactor = _mediaQueryData!.textScaleFactor;
    orientation = _mediaQueryData!.orientation;
    aspectRatio = screenWidth! / screenHeight!;

    blockSizeHorizontal = screenWidth! / targetWidth;
    blockSizeVertical = screenHeight! / targetHeight;

    _safeAreaHorizontal =
        _mediaQueryData!.padding.left + _mediaQueryData!.padding.right;

    _safeAreaVertical =
        _mediaQueryData!.padding.top + _mediaQueryData!.padding.bottom;

    safeBlockHorizontal =
        (screenWidth! - _safeAreaHorizontal!) / targetWidth;

    safeBlockVertical =
        (screenHeight! - _safeAreaVertical!) / targetHeight;

    _initialized = true;
  }

  /// Ensure initialized safely
  static void _ensureInitialized([BuildContext? context]) {
    if (_initialized) return;

    if (context != null) {
      _setup(context);
      return;
    }

    throw Exception(
      "ResponsiveLayout not initialized.\n"
          "Call ResponsiveLayout.init(context) before using it.",
    );
  }

  // -------------------------------
  // Helpers
  // -------------------------------

  static double getWidth(double width, {BuildContext? context}) {
    _ensureInitialized(context);
    return width * blockSizeHorizontal!;
  }

  static double getHeight(double height, {BuildContext? context}) {
    _ensureInitialized(context);
    return height * blockSizeVertical!;
  }

  static double getFontSize(double fontSize, {BuildContext? context}) {
    _ensureInitialized(context);
    final scaleFactor = min(blockSizeHorizontal!, blockSizeVertical!);
    return fontSize * max(scaleFactor, 0.8);
  }

  static double getAccessibleFontSize(double fontSize,
      {BuildContext? context}) {
    _ensureInitialized(context);
    return getFontSize(fontSize) * textScaleFactor!;
  }

  static double getIconSize(double size, {BuildContext? context}) {
    _ensureInitialized(context);
    final scaleFactor = min(blockSizeHorizontal!, blockSizeVertical!);
    return size * max(scaleFactor, 0.7);
  }

  static double getPadding(double padding, {BuildContext? context}) {
    _ensureInitialized(context);
    final scaleFactor = min(blockSizeHorizontal!, blockSizeVertical!);
    return padding * scaleFactor;
  }

  static double getRadius(double radius, {BuildContext? context}) {
    _ensureInitialized(context);
    return radius * blockSizeHorizontal!;
  }

  // -------------------------------
  // Device helpers
  // -------------------------------

  static bool isSmallScreen({BuildContext? context}) {
    _ensureInitialized(context);
    return screenWidth! < 800;
  }

  static bool isMediumScreen({BuildContext? context}) {
    _ensureInitialized(context);
    return screenWidth! >= 800 && screenWidth! < 1200;
  }

  static bool isLargeScreen({BuildContext? context}) {
    _ensureInitialized(context);
    return screenWidth! >= 1200;
  }

  static bool isPortrait({BuildContext? context}) {
    _ensureInitialized(context);
    return orientation == Orientation.portrait;
  }

  static bool isLandscape({BuildContext? context}) {
    _ensureInitialized(context);
    return orientation == Orientation.landscape;
  }

  static DeviceType getDeviceType({BuildContext? context}) {
    _ensureInitialized(context);
    if (screenWidth! < 600) return DeviceType.phone;
    if (screenWidth! < 1200) return DeviceType.tablet;
    return DeviceType.desktop;
  }

  static bool isPhone({BuildContext? context}) =>
      getDeviceType(context: context) == DeviceType.phone;

  static bool isTablet({BuildContext? context}) =>
      getDeviceType(context: context) == DeviceType.tablet;

  static bool isDesktop({BuildContext? context}) =>
      getDeviceType(context: context) == DeviceType.desktop;

  static AspectRatioType getAspectRatioType({BuildContext? context}) {
    _ensureInitialized(context);
    if (aspectRatio! > 1.7) return AspectRatioType.wide;
    if (aspectRatio! >= 1.3) return AspectRatioType.standard;
    return AspectRatioType.tall;
  }

  static EdgeInsets getContentPadding({BuildContext? context}) {
    _ensureInitialized(context);

    if (isPhone()) {
      return EdgeInsets.symmetric(
        horizontal: getWidth(16),
        vertical: getHeight(12),
      );
    } else if (isTablet()) {
      return EdgeInsets.symmetric(
        horizontal: getWidth(24),
        vertical: getHeight(16),
      );
    } else {
      return EdgeInsets.symmetric(
        horizontal: getWidth(32),
        vertical: getHeight(24),
      );
    }
  }
}

// -------------------------------
// Enums
// -------------------------------

enum DeviceType { phone, tablet, desktop, unknown }

enum AspectRatioType { wide, standard, tall }

class GridDimension {
  final int columns;
  final int rows;

  GridDimension(this.columns, this.rows);
}